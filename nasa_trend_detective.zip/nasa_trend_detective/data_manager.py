"""
src/data_manager.py
===================
Acquisition et chargement des données GLDAS pour Soil Trend Detective.

Deux modes, choisis automatiquement (mode="auto") :

* "real" : téléchargement des fichiers mensuels GLDAS depuis NASA GES DISC.
           Nécessite un compte NASA Earthdata (EARTHDATA_USERNAME / EARTHDATA_PASSWORD
           dans les variables d'environnement ou dans .streamlit/secrets.toml).
* "demo" : jeu synthétique, produit bloc par bloc (un bloc = une année), qui reproduit
           la structure et les variables de GLDAS avec un assèchement visible au Sahel.
           Il sert à développer et à présenter l'application sans identifiants.

Reprise sur interruption (idempotence)
--------------------------------------
* Chaque bloc terminé est inscrit dans un manifeste JSON (écriture atomique).
* Mode "real" : chaque fichier est écrit en `.part`. À la relance, l'en-tête HTTP
  `Range: bytes=<taille déjà reçue>-` reprend au bon octet. Un fichier complet n'est
  jamais retéléchargé.
* Mode "demo" : un bloc terminé n'est jamais régénéré. `interrupt_after` permet de
  simuler une coupure pour montrer la reprise.

Interface avec l'UI : `iter_acquisition()` est un générateur d'événements
(DownloadEvent). La page Streamlit met à jour sa barre de progression à chaque événement.

Variables canoniques exposées après chargement (noms et unités identiques dans les
deux modes) :
    soil_moisture (kg/m²), precipitation (mm/jour), temperature (°C),
    evapotranspiration (mm/jour), runoff (mm/jour)
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterator

import numpy as np
import pandas as pd
import requests
import streamlit as st
import xarray as xr

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = PROJECT_ROOT / "data" / "gldas"

START_YEAR, END_YEAR = 2003, 2023
CHUNK_BYTES = 1 << 20          # 1 Mio par lecture réseau
HTTP_TIMEOUT = 30              # secondes

# Modèle d'URL GLDAS Noah 1.0° mensuel (v2.1). À vérifier sur GES DISC si la NASA
# change de version ou d'hôte : c'est la seule constante à modifier.
GLDAS_BASE_URL = "https://hydro1.gesdisc.eosdis.nasa.gov/data/GLDAS/GLDAS_NOAH10_M.2.1"
GLDAS_FILE_PATTERN = "{year}/GLDAS_NOAH10_M.A{year}{month:02d}.021.nc4"

# Variable GLDAS -> (nom canonique, fonction de conversion d'unité).
# Rainf_f_tavg et Evap_tavg sont en kg/m²/s ; Qs_acc est cumulé sur 3 h (8 pas par jour).
GLDAS_TO_CANONICAL: dict[str, tuple[str, Callable[[xr.DataArray], xr.DataArray], str]] = {
    "SoilMoi0_10cm_inst": ("soil_moisture", lambda x: x, "kg m-2"),
    "Rainf_f_tavg": ("precipitation", lambda x: x * 86400.0, "mm day-1"),
    "Tair_f_inst": ("temperature", lambda x: x - 273.15, "degC"),
    "Evap_tavg": ("evapotranspiration", lambda x: x * 86400.0, "mm day-1"),
    "Qs_acc": ("runoff", lambda x: x * 8.0, "mm day-1"),
}
CANONICAL_VARS = tuple(v[0] for v in GLDAS_TO_CANONICAL.values())


# --------------------------------------------------------------------------
# Événements pour l'interface
# --------------------------------------------------------------------------
@dataclass
class DownloadEvent:
    """
    kind : "start" | "resumed" | "chunk" | "cached" | "done" | "interrupted" | "error"
    done / total : blocs terminés / blocs au total (pour la barre de progression)
    detail : message technique (erreurs) ou nombre de fichiers (fin)
    """
    kind: str
    done: int = 0
    total: int = 0
    detail: str = ""
    mode: str = "demo"

    @property
    def fraction(self) -> float:
        return self.done / self.total if self.total else 0.0


# --------------------------------------------------------------------------
# Identifiants et choix du mode
# --------------------------------------------------------------------------
def _get_credentials() -> tuple[str, str] | None:
    """Cherche les identifiants Earthdata dans l'environnement puis dans st.secrets."""
    user = os.environ.get("EARTHDATA_USERNAME")
    password = os.environ.get("EARTHDATA_PASSWORD")
    if not (user and password):
        try:
            user = st.secrets.get("EARTHDATA_USERNAME")
            password = st.secrets.get("EARTHDATA_PASSWORD")
        except Exception:  # pas de fichier secrets.toml
            user = password = None
    return (user, password) if user and password else None


def resolve_mode(mode: str = "auto") -> str:
    """Retourne "real" ou "demo". En auto : "real" seulement si des identifiants existent."""
    if mode in ("real", "demo"):
        return mode
    return "real" if _get_credentials() else "demo"


def mode_dir(mode: str) -> Path:
    return DATA_ROOT / mode


# --------------------------------------------------------------------------
# Manifeste (suivi des blocs terminés, écriture atomique)
# --------------------------------------------------------------------------
def _manifest_path(mode: str) -> Path:
    return mode_dir(mode) / "manifest.json"


def _read_manifest(mode: str) -> dict:
    path = _manifest_path(mode)
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass  # manifeste corrompu : on repart d'un état vide, les fichiers valides sont retestés
    return {"completed": []}


def _write_manifest(mode: str, manifest: dict) -> None:
    path = _manifest_path(mode)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    tmp.replace(path)  # remplacement atomique : jamais de manifeste à moitié écrit


def _done_chunks(mode: str) -> set[str]:
    """Blocs marqués terminés ET dont le fichier existe réellement sur le disque."""
    base = mode_dir(mode)
    return {name for name in _read_manifest(mode)["completed"] if (base / name).exists()}


def _mark_done(mode: str, name: str) -> None:
    manifest = _read_manifest(mode)
    if name not in manifest["completed"]:
        manifest["completed"].append(name)
    _write_manifest(mode, manifest)


# --------------------------------------------------------------------------
# Plan de téléchargement
# --------------------------------------------------------------------------
def build_plan(mode: str, years: range | None = None) -> list[str]:
    """Liste ordonnée des noms de fichiers (un par bloc) pour le mode donné."""
    years = years or range(START_YEAR, END_YEAR + 1)
    if mode == "demo":
        return [f"gldas_demo_{y}.nc" for y in years]
    return [
        Path(GLDAS_FILE_PATTERN.format(year=y, month=m)).name
        for y in years
        for m in range(1, 13)
    ]


def _real_url(filename: str) -> str:
    """Reconstruit l'URL à partir du nom de fichier GLDAS_NOAH10_M.A<YYYYMM>.021.nc4."""
    year = int(filename.split(".A")[1][:4])
    return f"{GLDAS_BASE_URL}/{year}/{filename}"


def get_status(mode: str) -> dict:
    """État courant pour l'UI : blocs terminés, total, prêt ou non."""
    plan = build_plan(mode)
    done = _done_chunks(mode) & set(plan)
    return {"mode": mode, "done": len(done), "total": len(plan), "ready": len(done) == len(plan)}


def get_ready_mode() -> str | None:
    """Mode dont les données sont complètes ("real" prioritaire), sinon None."""
    for mode in ("real", "demo"):
        if get_status(mode)["ready"]:
            return mode
    return None


# --------------------------------------------------------------------------
# Téléchargement réel avec reprise (en-tête Range)
# --------------------------------------------------------------------------
class EarthdataSession(requests.Session):
    """
    Session `requests` qui conserve l'authentification pendant les redirections
    vers urs.earthdata.nasa.gov (comportement exigé par NASA Earthdata Login).
    """

    AUTH_HOST = "urs.earthdata.nasa.gov"

    def rebuild_auth(self, prepared_request, response):
        headers = prepared_request.headers
        if "Authorization" in headers:
            original = requests.utils.urlparse(response.request.url).hostname
            redirect = requests.utils.urlparse(prepared_request.url).hostname
            if redirect != original and self.AUTH_HOST not in (original, redirect):
                del headers["Authorization"]


def download_with_resume(
    session: requests.Session,
    url: str,
    dest: Path,
    on_bytes: Callable[[int, int | None], None] | None = None,
) -> Path:
    """
    Télécharge `url` vers `dest`, en reprenant un `.part` existant.

    * `dest` existe déjà  -> rien à faire (idempotent).
    * `.part` de N octets -> requête `Range: bytes=N-`.
    * 206 Partial Content -> on ajoute à la suite du .part.
    * 200 OK              -> le serveur ignore Range : on repart de zéro.
    * 416                 -> le .part est déjà complet : on le valide.
    En cas de coupure, le .part reste sur le disque pour la prochaine reprise.
    """
    if dest.exists() and dest.stat().st_size > 0:
        return dest

    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    start = part.stat().st_size if part.exists() else 0
    headers = {"Range": f"bytes={start}-"} if start else {}

    with session.get(url, headers=headers, stream=True, timeout=HTTP_TIMEOUT) as resp:
        if resp.status_code == 416:
            part.replace(dest)
            return dest
        resp.raise_for_status()

        if resp.status_code == 200:
            start = 0  # Range ignoré : écriture depuis le début
        content_range = resp.headers.get("Content-Range")  # "bytes 100-999/1000"
        if content_range:
            total = int(content_range.split("/")[-1])
        elif "Content-Length" in resp.headers:
            total = start + int(resp.headers["Content-Length"])
        else:
            total = None

        received = start
        with open(part, "ab" if start else "wb") as fh:
            for block in resp.iter_content(CHUNK_BYTES):
                if block:
                    fh.write(block)
                    received += len(block)
                    if on_bytes:
                        on_bytes(received, total)

    if total is not None and part.stat().st_size != total:
        raise IOError(f"Fichier incomplet : {part.stat().st_size}/{total} octets")
    part.replace(dest)
    return dest


# --------------------------------------------------------------------------
# Jeu de démonstration synthétique (un bloc = une année)
# --------------------------------------------------------------------------
_LATS = np.arange(-34.0, 38.0, 2.0)
_LONS = np.arange(-18.0, 52.0, 2.0)
_SEED = 237


def _synthetic_year(year: int) -> xr.Dataset:
    """
    Produit 12 mois de données pour l'Afrique, avec la physique simplifiée suivante :
    l'humidité du sol augmente avec les pluies, baisse avec l'évapotranspiration et
    avec un assèchement tendanciel concentré au Sahel et en Afrique australe.
    Déterministe : une même année donne toujours les mêmes valeurs.
    """
    rng = np.random.default_rng(_SEED + year)
    lat, lon = np.meshgrid(_LATS, _LONS, indexing="ij")
    months = np.arange(12)
    times = pd.date_range(f"{year}-01-01", periods=12, freq="MS")
    yrs = (year - START_YEAR) + (months + 0.5) / 12                      # (12,)

    season = np.cos(2 * np.pi * (months - 6.5) / 12)[:, None, None]      # pic en juillet
    seasonal = season * np.tanh(lat / 8)[None]                           # inversé au sud
    wetness = np.exp(-((lat / 14) ** 2))[None]                           # ceinture équatoriale humide
    noise = lambda s: rng.normal(0, s, (12, *lat.shape))                 # noqa: E731
    t = yrs[:, None, None]

    temperature = 30 - 0.35 * np.abs(lat)[None] + 3 * seasonal + 0.04 * t + noise(0.5)
    precipitation = np.clip(0.3 + 5.5 * wetness * (1 + 0.7 * seasonal) + noise(0.6), 0, None)
    evapotranspiration = np.clip(
        0.5 + 0.08 * (temperature - 10) * (0.4 + wetness) + noise(0.1), 0, None
    )
    runoff = np.clip(0.12 * precipitation * wetness + noise(0.03), 0, None)

    hotspot = (0.06 + 0.28 * np.exp(-(((lat - 12) / 8) ** 2))            # Sahel
               + 0.20 * np.exp(-(((lat + 22) / 7) ** 2)))[None]          # Afrique australe
    soil = np.clip(10 + 3.0 * precipitation - 4.0 * evapotranspiration - hotspot * t + noise(0.6), 3, 45)

    coords = {"time": times, "lat": _LATS, "lon": _LONS}
    dims = ("time", "lat", "lon")
    units = {v: u for _, (v, _, u) in GLDAS_TO_CANONICAL.items()}
    ds = xr.Dataset(
        {
            "soil_moisture": (dims, soil.astype("float32")),
            "precipitation": (dims, precipitation.astype("float32")),
            "temperature": (dims, temperature.astype("float32")),
            "evapotranspiration": (dims, evapotranspiration.astype("float32")),
            "runoff": (dims, runoff.astype("float32")),
        },
        coords=coords,
    )
    for name, unit in units.items():
        ds[name].attrs["units"] = unit
    ds.attrs["title"] = "Jeu de démonstration synthétique inspiré de GLDAS"
    return ds


# --------------------------------------------------------------------------
# Orchestration : générateur d'événements pour la barre de progression
# --------------------------------------------------------------------------
def iter_acquisition(
    mode: str = "auto",
    interrupt_after: int | None = None,
    pace: float = 0.12,
    years: range | None = None,
) -> Iterator[DownloadEvent]:
    """
    Lance (ou reprend) l'acquisition et émet un DownloadEvent par étape.

    interrupt_after : en démo, coupe après N nouveaux blocs pour montrer la reprise.
    pace            : pause artificielle (secondes) par bloc en démo, pour que la barre
                      de progression soit visible. Mettre 0 pour aller vite.
    """
    mode = resolve_mode(mode)
    plan = build_plan(mode, years)
    total = len(plan)
    base = mode_dir(mode)
    base.mkdir(parents=True, exist_ok=True)

    already = _done_chunks(mode) & set(plan)
    if len(already) == total:
        yield DownloadEvent("cached", total, total, mode=mode)
        return

    yield DownloadEvent("start", len(already), total, mode=mode)
    if already:
        yield DownloadEvent("resumed", len(already), total, mode=mode)

    session = None
    if mode == "real":
        creds = _get_credentials()
        session = EarthdataSession()
        session.auth = creds

    done = len(already)
    produced = 0
    for name in plan:
        if name in already:
            continue
        if interrupt_after is not None and produced >= interrupt_after:
            yield DownloadEvent("interrupted", done, total, mode=mode)
            return
        try:
            if mode == "demo":
                tmp = base / f"{name}.part"
                _synthetic_year(int(name.split("_")[-1][:4])).to_netcdf(tmp)
                tmp.replace(base / name)
                time.sleep(pace)
            else:
                download_with_resume(session, _real_url(name), base / name)
        except (requests.ConnectionError, requests.Timeout, requests.exceptions.ChunkedEncodingError):
            yield DownloadEvent("interrupted", done, total, mode=mode)
            return
        except Exception as exc:  # erreur définitive (401, 404, disque plein...)
            yield DownloadEvent("error", done, total, detail=str(exc), mode=mode)
            return

        _mark_done(mode, name)
        done += 1
        produced += 1
        yield DownloadEvent("chunk", done, total, mode=mode)

    yield DownloadEvent("done", done, total, detail=str(done), mode=mode)


# --------------------------------------------------------------------------
# Chargement xarray (mis en cache)
# --------------------------------------------------------------------------
def _normalize(ds: xr.Dataset) -> xr.Dataset:
    """Renomme les variables GLDAS en noms canoniques et convertit les unités."""
    out = {}
    for gldas_name, (canon, convert, unit) in GLDAS_TO_CANONICAL.items():
        if gldas_name in ds:
            da = convert(ds[gldas_name])
            da.attrs["units"] = unit
            out[canon] = da
        elif canon in ds:  # déjà canonique (jeu de démonstration)
            out[canon] = ds[canon]
    return xr.Dataset(out)


def dataset_signature(mode: str) -> str:
    """Empreinte du contenu du manifeste : change dès qu'un bloc est ajouté."""
    raw = json.dumps(sorted(_done_chunks(mode)))
    return hashlib.md5(raw.encode()).hexdigest()


@st.cache_data(show_spinner=False)
def _load_dataset_cached(mode: str, signature: str) -> xr.Dataset:
    """
    Charge tous les blocs terminés et les concatène sur l'axe du temps.
    `signature` n'est pas utilisée dans le calcul : elle invalide le cache quand
    de nouvelles données arrivent.
    """
    base = mode_dir(mode)
    parts = []
    for name in sorted(_done_chunks(mode)):
        with xr.open_dataset(base / name) as raw:
            parts.append(_normalize(raw).load())
    if not parts:
        raise FileNotFoundError(f"Aucune donnée complète dans {base}")
    ds = xr.concat(parts, dim="time").sortby("time")
    if "lat" in ds.dims:
        ds = ds.sortby("lat")
    return ds


def load_dataset(mode: str | None = None) -> xr.Dataset:
    """
    Point d'entrée du chargement. Sans argument, prend le premier mode dont les données
    sont complètes. Lève FileNotFoundError si rien n'est disponible : l'UI doit alors
    afficher t("dash.no_data").
    """
    mode = mode or get_ready_mode()
    if mode is None:
        raise FileNotFoundError("Aucune donnée complète : lancer l'acquisition d'abord.")
    return _load_dataset_cached(mode, dataset_signature(mode))


@st.cache_data(show_spinner=False)
def dataset_summary(mode: str, signature: str) -> dict:
    """Résumé léger du jeu chargé (période, grille, variables), affichable en UI."""
    ds = _load_dataset_cached(mode, signature)
    return {
        "start": str(ds.time.min().values)[:10],
        "end": str(ds.time.max().values)[:10],
        "n_months": int(ds.sizes["time"]),
        "grid": (int(ds.sizes["lat"]), int(ds.sizes["lon"])),
        "variables": list(ds.data_vars),
    }
