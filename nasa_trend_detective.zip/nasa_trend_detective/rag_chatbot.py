"""
src/rag_chatbot.py
==================
Assistant IA de Soil Trend Detective : explique l'assèchement des sols et le rôle des
variables (humidité du sol, précipitations, température, évapotranspiration,
ruissellement, aérosols) à partir de trois sources :

1. RÉSULTATS DE L'ANALYSE  : tendance Mann-Kendall, contributions SHAP, variables
                             disponibles, origine des données (build_app_context).
2. FICHE DES VARIABLES     : connaissances scientifiques sur le rôle de chaque variable
                             (VARIABLE_KNOWLEDGE ci-dessous).
3. DOCUMENTS (optionnel)   : fichiers .md/.txt/.pdf de data/docs, indexés dans ChromaDB.

"""

from __future__ import annotations

import hashlib
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import streamlit as st
from langchain_core.documents import Document
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_text_splitters import RecursiveCharacterTextSplitter

from src.i18n import get_language

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DOCS_DIR = PROJECT_ROOT / "data" / "docs"
CHROMA_DIR = PROJECT_ROOT / "data" / "chroma"

DEFAULT_LLM_MODEL = "gemini-3.8-flash"
DEFAULT_EMBEDDING_MODEL = "models/gemini-embedding-001"
TEMPERATURE = 1.0            # valeur recommandée par Google pour tous les modèles Gemini 3
MAX_OUTPUT_TOKENS = 4096     # la réflexion interne est comptée dans ce plafond
TOP_K = 3
HISTORY_MESSAGES = 6         # derniers messages transmis au modèle
MAX_HISTORY_CHARS = 1200

ANALYSIS_SOURCE = {"fr": "Analyse de l'application", "en": "Application analysis"}


class MissingLLMKey(RuntimeError):
    """Aucune clé d'API Gemini n'est configurée."""


class EmptyAnswer(RuntimeError):
    """Le modèle a répondu sans aucun texte exploitable."""


@dataclass
class ChatAnswer:
    text: str
    sources: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)   # avertissements non bloquants


def _tr(fr: str, en: str) -> str:
    return fr if get_language() == "fr" else en


# --------------------------------------------------------------------------
# Connaissances sur les variables
# --------------------------------------------------------------------------
# (nom en français, unité)
VARIABLE_LABELS: dict[str, tuple[str, str]] = {
    "soil_moisture": ("humidité du sol", "kg/m²"),
    "precipitation": ("précipitations", "mm/jour"),
    "temperature": ("température de l'air", "°C"),
    "evapotranspiration": ("évapotranspiration", "mm/jour"),
    "runoff": ("ruissellement", "mm/jour"),
    "aerosol": ("aérosols", ""),
}

VARIABLE_KNOWLEDGE: dict[str, str] = {
    "soil_moisture": (
        "Humidité du sol (variable étudiée) : eau stockée dans la couche superficielle "
        "(0 à 10 cm dans GLDAS), en kg/m². C'est l'eau immédiatement disponible pour les "
        "racines. Une baisse durable signale un stress hydrique ; l'agriculture pluviale "
        "y est la plus exposée."
    ),
    "precipitation": (
        "Précipitations : principal apport d'eau au sol. Moins de pluie, ou une pluie plus "
        "irrégulière, réduit la recharge. Une même quantité tombant en averses violentes "
        "s'infiltre moins bien qu'une pluie étalée dans le temps."
    ),
    "temperature": (
        "Température de l'air : elle ne contient pas d'eau mais augmente la demande "
        "évaporative de l'atmosphère. Plus il fait chaud, plus l'air prélève d'eau dans le "
        "sol et les plantes (évapotranspiration). À précipitations constantes, le "
        "réchauffement accélère donc l'assèchement."
    ),
    "evapotranspiration": (
        "Évapotranspiration : eau qui retourne à l'atmosphère par évaporation du sol et "
        "transpiration des plantes. C'est la principale perte d'eau du sol. Forte chaleur et "
        "pluie faible donnent un déficit. Nuance : quand le sol est déjà très sec, il reste "
        "peu d'eau à évaporer et l'évapotranspiration peut elle-même diminuer."
    ),
    "runoff": (
        "Ruissellement : eau de pluie qui s'écoule en surface au lieu de s'infiltrer. Un fort "
        "ruissellement (averses intenses, sol sec et durci, pente, sol nu) prive le sol "
        "d'eau et peut aggraver la sécheresse locale. Un ruissellement faible ne garantit "
        "pas un sol humide."
    ),
    "aerosol": (
        "Aérosols (poussières, fumées, pollution) : particules en suspension. Elles réduisent "
        "le rayonnement solaire qui atteint le sol, ce qui peut le refroidir en surface, et "
        "modifient la formation des nuages et des pluies. Leur effet sur l'humidité du sol "
        "est indirect, variable selon les régions et plus incertain que celui des autres "
        "variables."
    ),
}


def detect_variables(ds) -> tuple[list[str], list[str]]:
    """
    Sépare les variables réellement présentes de celles qui manquent.
    Une variable remplie de zéros (valeur de remplacement à l'import de fichiers) compte
    comme absente : le chatbot ne doit pas lui attribuer une contribution.
    """
    available, missing = [], []
    for name in VARIABLE_LABELS:
        present = False
        if name in ds:
            values = np.asarray(ds[name].to_numpy(), dtype=float)
            present = bool(np.isfinite(values).any() and np.nanmax(np.abs(values)) > 0)
        (available if present else missing).append(name)
    return available, missing


# --------------------------------------------------------------------------
# Contexte envoyé au modèle
# --------------------------------------------------------------------------
_DIRECTION_FR = {
    "decreasing": "baisse significative (assèchement)",
    "increasing": "hausse significative (humidification)",
    "no_trend": "aucune tendance significative",
}


def _r2_quality(r2: float) -> str:
    if r2 >= 0.7:
        return "bonne : explications fiables"
    if r2 >= 0.4:
        return "moyenne : à interpréter avec prudence"
    return "faible : explications peu fiables"


def build_app_context(region_label: str, trend, shap_result: dict | None,
                      available: list[str], missing: list[str], source: str) -> str:
    """
    Transforme les résultats affichés à l'écran en texte pour le modèle.
    trend       : analytics.TrendResult ou None
    shap_result : explainability.explain_region(...) ou None
    source      : "demo", "real" ou "custom"
    """
    origin = {
        "demo": "jeu de démonstration SYNTHÉTIQUE inspiré de GLDAS (ce ne sont pas des "
                "observations réelles)",
        "real": "données réelles GLDAS (NASA GES DISC)",
        "custom": "fichiers importés par l'utilisateur",
    }.get(source, source)

    lines = [
        f"Zone d'étude : {region_label}.",
        f"Origine des données : {origin}.",
        "Variables disponibles : " + ", ".join(
            f"{VARIABLE_LABELS[v][0]} ({VARIABLE_LABELS[v][1]})".replace(" ()", "")
            for v in available) + ".",
    ]
    if missing:
        lines.append("Variables ABSENTES des données actuelles : " + ", ".join(
            VARIABLE_LABELS[v][0] for v in missing) + ".")

    lines.append("\nTENDANCE DE L'HUMIDITÉ DU SOL (test de Mann-Kendall saisonnier, pente de Theil-Sen) :")
    if trend is None:
        lines.append("- Non calculée (données insuffisantes).")
    else:
        lines += [
            f"- Résultat : {_DIRECTION_FR.get(trend.direction, trend.direction)}.",
            f"- Valeur p = {trend.p_value:.4f} (seuil de significativité 0,05) ; "
            f"tau de Kendall = {trend.tau:+.2f} ; pente de Theil-Sen = "
            f"{trend.slope_per_year:+.3f} kg/m² par an ; {trend.n_months} mois analysés.",
        ]

    lines.append("\nEXPLICATION SHAP (situation moyenne des 12 derniers mois) :")
    if not shap_result:
        lines.append("- Non disponible (données insuffisantes pour entraîner le modèle).")
    else:
        lines.append(
            f"- Humidité du sol prédite : {shap_result['prediction']:.1f} kg/m², contre "
            f"{shap_result['base_value']:.1f} kg/m² en moyenne pour le modèle.")
        lines.append("- Contribution de chaque variable (négatif = assèche, positif = humidifie) :")
        ranked = sorted(shap_result["contributions"].items(), key=lambda kv: abs(kv[1]), reverse=True)
        for name, contrib in ranked:
            if name in missing:
                continue
            label, unit = VARIABLE_LABELS.get(name, (name, ""))
            value = shap_result["feature_values"].get(name)
            effect = "assèche" if contrib < 0 else "humidifie"
            lines.append(
                f"  * {label} : valeur récente {value:.2f} {unit}".rstrip()
                + f" ; contribution {contrib:+.2f} kg/m² ({effect}) ; "
                f"part de l'influence {shap_result['shares'][name]:.0f} %.")
        lines.append(f"- Qualité du modèle (R² sur données non vues) : {shap_result['r2']:.2f}, "
                     f"{_r2_quality(shap_result['r2'])}.")
        lines.append("- SHAP décrit comment le modèle associe les variables à l'humidité du sol : "
                     "ce n'est pas une preuve de causalité.")
    return "\n".join(lines)


def _knowledge_sheet(available: list[str]) -> str:
    """Fiche des variables : toutes celles du projet, y compris absentes (rôle général)."""
    return "\n".join(f"- {text}" for text in VARIABLE_KNOWLEDGE.values())


_SYSTEM_PROMPT = """Tu es l'Assistant Scientifique de « Soil Trend Detective » (NASA Space Apps Challenge, défi Earth System Trend Detective).
Ta mission : expliquer l'assèchement des sols et le rôle des variables étudiées (humidité du sol, précipitations, température, évapotranspiration, ruissellement, aérosols), ainsi que les méthodes de l'application (test de Mann-Kendall, pente de Theil-Sen, SHAP, simulateur What-If), à des lecteurs non experts : agriculteurs, décideurs, étudiants.

SOURCES
1. RÉSULTATS DE L'ANALYSE : la seule source autorisée pour les chiffres (valeur p, pente, parts SHAP, valeurs des variables).
2. FICHE DES VARIABLES : connaissances scientifiques sur le rôle de chaque variable.
3. EXTRAITS DE DOCUMENTS : s'il y en a, utilise-les et cite leur nom.

RÈGLES
- N'invente jamais un chiffre. Si une valeur n'est pas dans les RÉSULTATS, dis qu'elle n'est pas disponible dans l'analyse actuelle.
- Pour expliquer un mécanisme, appuie-toi sur la fiche des variables et sur la physique générale du bilan hydrique du sol. Distingue clairement ce que MONTRE l'analyse de ce qui est une explication générale.
- Pourquoi le sol est sec : classe les variables par part d'influence SHAP, indique si chacune assèche ou humidifie, puis explique le mécanisme physique en une phrase chacune. Si le sol n'est pas plus sec que la moyenne du modèle, dis-le.
- SHAP décrit le modèle, pas la causalité : emploie « le modèle associe », pas « la cause est ».
- Variable ABSENTE des données : dis-le, explique son rôle général, ne lui attribue aucune contribution chiffrée.
- Si les données sont synthétiques (démonstration), rappelle-le dès que tu tires une conclusion sur le monde réel.
- Si le modèle SHAP a un R² faible, signale que l'explication est peu fiable.
- Hors sujet (rien à voir avec les sols, la sécheresse, les variables ci-dessus, les méthodes de l'application ou les impacts de la sécheresse) : refuse en une phrase aimable et propose 2 ou 3 questions pertinentes. Une salutation reçoit une réponse brève et une proposition d'aide.
- Tiens compte de l'historique de la conversation pour les questions de suivi.

STYLE
- Réponds en {language}. Clair, sans jargon inutile, entre 120 et 250 mots sauf si on demande plus de détail. Un court paragraphe, puis une liste si elle aide. Aucun emoji.
- Termine les affirmations importantes par leur source entre crochets : [Analyse], [Fiche variables] ou [nom du fichier]. Ne cite jamais une source qui n'existe pas.

=== RÉSULTATS DE L'ANALYSE ===
{app_context}

=== FICHE DES VARIABLES ===
{knowledge}

=== EXTRAITS DE DOCUMENTS ===
{docs_context}
"""


def _system_prompt(app_context: str, docs_context: str, available: list[str]) -> str:
    language = "français" if get_language() == "fr" else "English (US)"
    return _SYSTEM_PROMPT.format(language=language, app_context=app_context,
                                 knowledge=_knowledge_sheet(available), docs_context=docs_context)


# --------------------------------------------------------------------------
# Configuration et clés
# --------------------------------------------------------------------------
def _secret(name: str) -> str | None:
    value = os.environ.get(name)
    if value:
        return value
    try:
        return st.secrets.get(name)
    except Exception:
        return None


def _api_key() -> str:
    key = _secret("GEMINI_API_KEY") or _secret("GOOGLE_API_KEY")
    if not key:
        raise MissingLLMKey(_tr(
            "Clé d'API Gemini introuvable. Ajoutez GEMINI_API_KEY dans .streamlit/secrets.toml.",
            "Gemini API key not found. Add GEMINI_API_KEY to .streamlit/secrets.toml."))
    return key


def _llm_model() -> str:
    return _secret("GEMINI_MODEL") or DEFAULT_LLM_MODEL


def _embedding_model() -> str:
    return _secret("EMBEDDING_MODEL") or DEFAULT_EMBEDDING_MODEL


# --------------------------------------------------------------------------
# Modèle de langage
# --------------------------------------------------------------------------
@st.cache_resource(show_spinner=False)
def _build_llm(api_key: str, model: str, low_thinking: bool):
    from langchain_google_genai import ChatGoogleGenerativeAI

    kwargs = dict(model=model, temperature=TEMPERATURE, max_output_tokens=MAX_OUTPUT_TOKENS,
                  google_api_key=api_key)
    if low_thinking:
        kwargs["thinking_level"] = "low"   # réponses plus rapides ; ignoré si non supporté
    return ChatGoogleGenerativeAI(**kwargs)


def _message_text(message) -> str:
    """
    Extrait le texte d'une réponse. Avec Gemini 3, `content` peut être une liste de blocs
    (texte, réflexion...) : on ne garde que les blocs de texte.
    """
    content = getattr(message, "content", message)
    if isinstance(content, str):
        return content
    parts: list[str] = []
    if isinstance(content, list):
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict) and block.get("type", "text") == "text":
                parts.append(str(block.get("text", "")))
    return "".join(parts)


def _generate(messages: list) -> str:
    """
    Appelle Gemini. Essaie d'abord avec réflexion réduite (rapide), puis sans ce paramètre
    si la version installée de langchain-google-genai ou le modèle ne l'accepte pas.
    """
    key, model = _api_key(), _llm_model()
    last_error: Exception | None = None
    for low in (True, False):
        try:
            reply = _build_llm(key, model, low).invoke(messages)
            text = _message_text(reply).strip()
            if text:
                return text
            last_error = EmptyAnswer(_tr("Le modèle a renvoyé une réponse vide.",
                                         "The model returned an empty answer."))
        except MissingLLMKey:
            raise
        except Exception as exc:  # paramètre refusé, réseau, quota...
            last_error = exc
    raise last_error  # type: ignore[misc]


# --------------------------------------------------------------------------
# Documents (RAG optionnel)
# --------------------------------------------------------------------------
def _read_file(path: Path) -> str:
    if path.suffix.lower() == ".pdf":
        from pypdf import PdfReader
        return "\n".join(page.extract_text() or "" for page in PdfReader(str(path)).pages)
    return path.read_text(encoding="utf-8", errors="ignore")


def load_documents(docs_dir: Path = DOCS_DIR) -> list[Document]:
    splitter = RecursiveCharacterTextSplitter(chunk_size=900, chunk_overlap=120)
    docs: list[Document] = []
    if not docs_dir.exists():
        return docs
    for path in sorted(docs_dir.glob("*")):
        if path.suffix.lower() in {".md", ".txt", ".pdf"} and path.name.lower() != "readme.md":
            docs += splitter.create_documents([_read_file(path)], metadatas=[{"source": path.name}])
    return docs


def _docs_signature(docs_dir: Path = DOCS_DIR) -> str:
    if not docs_dir.exists():
        return "empty"
    parts = [f"{p.name}:{p.stat().st_size}:{int(p.stat().st_mtime)}"
             for p in sorted(docs_dir.glob("*")) if p.is_file()]
    return hashlib.md5("|".join(parts).encode()).hexdigest()[:12]


@st.cache_resource(show_spinner=False)
def _embeddings(api_key: str, model: str):
    from langchain_google_genai import GoogleGenerativeAIEmbeddings
    return GoogleGenerativeAIEmbeddings(model=model, google_api_key=api_key)


@st.cache_resource(show_spinner=False)
def _docs_store(signature: str, embedding_model: str, api_key: str):
    """Base Chroma persistante. Le nom de collection inclut le modèle d'embeddings."""
    from langchain_chroma import Chroma

    docs = load_documents()
    if not docs:
        return None
    tag = hashlib.md5(embedding_model.encode()).hexdigest()[:6]
    return Chroma.from_documents(
        docs, _embeddings(api_key, embedding_model), collection_name=f"docs_{tag}_{signature}",
        persist_directory=str(CHROMA_DIR))


def retrieve_docs(question: str) -> tuple[list[Document], str | None]:
    """Retourne (passages, avertissement). Une erreur n'est plus silencieuse."""
    if not DOCS_DIR.exists() or not load_documents():
        return [], None
    try:
        store = _docs_store(_docs_signature(), _embedding_model(), _api_key())
        return (store.similarity_search(question, k=TOP_K) if store else []), None
    except MissingLLMKey:
        raise
    except Exception as exc:
        return [], _tr(f"Documents indisponibles ({type(exc).__name__}: {exc}).",
                       f"Documents unavailable ({type(exc).__name__}: {exc}).")


# --------------------------------------------------------------------------
# API publique
# --------------------------------------------------------------------------
def answer_question(question: str, app_context: str, available: list[str] | None = None,
                    history: list[tuple[str, str]] | None = None) -> ChatAnswer:
    """
    Répond à `question`.
    history : [("user"|"assistant", texte), ...] des échanges précédents (sans la question).
    Lève MissingLLMKey (pas de clé) ou une exception réseau/API : l'appelant décide du repli.
    """
    notes: list[str] = []
    passages, note = retrieve_docs(question)
    if note:
        notes.append(note)
    docs_context = "\n\n".join(f"[{d.metadata.get('source', '?')}] {d.page_content}"
                               for d in passages) or "(aucun document fourni)"

    messages: list = [SystemMessage(content=_system_prompt(app_context, docs_context,
                                                           available or []))]
    for role, content in (history or [])[-HISTORY_MESSAGES:]:
        cls = HumanMessage if role == "user" else AIMessage
        messages.append(cls(content=content[:MAX_HISTORY_CHARS]))
    messages.append(HumanMessage(content=question))

    text = _generate(messages)
    sources = [ANALYSIS_SOURCE[get_language()]] + sorted(
        {d.metadata.get("source", "?") for d in passages})
    return ChatAnswer(text=text, sources=sources, notes=notes)


_WHY_PATTERN = re.compile(
    r"\b(pourquoi|expliqu\w*|cause\w*|raison\w*|why|explain\w*|reason\w*)\b", re.IGNORECASE)
_DRY_PATTERN = re.compile(
    r"\b(sec|s[eè]che|s[eé]cheresse|ass[eè]ch\w*|dry|drought|dries|drying)\b", re.IGNORECASE)


def wants_explanation(question: str) -> bool:
    """Vrai pour « Pourquoi le sol est-il sec ici ? » ou « Why is the soil dry? »."""
    return bool(_WHY_PATTERN.search(question) and _DRY_PATTERN.search(question))


def diagnose() -> dict:
    """Test de bout en bout (clé, modèle de langage, embeddings) pour repérer la panne."""
    report: dict = {"llm_model": _llm_model(), "embedding_model": _embedding_model()}
    try:
        report["api_key"] = bool(_api_key())
    except MissingLLMKey as exc:
        report["api_key"] = False
        report["error"] = str(exc)
        return report
    try:
        report["llm_reply"] = _generate([HumanMessage(content="Réponds uniquement par le mot OK.")])[:60]
        report["llm_ok"] = True
    except Exception as exc:
        report["llm_ok"] = False
        report["llm_error"] = f"{type(exc).__name__}: {exc}"
    try:
        vector = _embeddings(_api_key(), _embedding_model()).embed_query("test")
        report["embeddings_ok"] = True
        report["embedding_dimensions"] = len(vector)
    except Exception as exc:
        report["embeddings_ok"] = False
        report["embeddings_error"] = f"{type(exc).__name__}: {exc}"
    return report
