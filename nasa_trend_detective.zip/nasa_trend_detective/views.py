"""
src/views.py
============
Pages du workspace (le contenu de chaque onglet de la sidebar).
app.py ne fait que router vers ces trois fonctions :

    render_acquisition()  : téléchargement des données avec barre de progression
    render_dashboard()    : carte animée, test de Mann-Kendall, simulateur What-If
    render_assistant()    : chatbot RAG et Glass Box SHAP
"""

from __future__ import annotations

import streamlit as st

from src import analytics, data_manager as dm
from src.i18n import t
from src.ui_components import (MOISTURE_COLORSCALE, apply_plotly_theme, glass_container,
                               page_header, trend_badge)


def _selected_region() -> str:
    """Zone d'étude partagée entre le tableau de bord et l'assistant."""
    return st.session_state.setdefault("region", "sahel")


def _region_selector() -> str:
    st.selectbox(
        t("region.label"), options=list(analytics.REGIONS), key="region",
        format_func=lambda r: t(f"region.{r}"),
    )
    return st.session_state["region"]


# --------------------------------------------------------------------------
# 1. Acquisition
# --------------------------------------------------------------------------
_STATUS_KEYS = {"start": "acq.status.downloading", "chunk": "acq.status.chunk",
                "resumed": "acq.status.resumed", "interrupted": "acq.status.interrupted",
                "done": "acq.status.done", "cached": "acq.status.cached"}


def render_acquisition() -> None:
    page_header(t("acq.title"), t("acq.subtitle"), "cloud_download")

    mode = dm.resolve_mode("auto")
    status = dm.get_status(mode)

    with glass_container("acq_dataset"):
        st.markdown(f"#### :material/database: {t('acq.dataset.title')}")
        st.markdown(f"**{t('acq.dataset.name')}**  \n{t('acq.dataset.variables')}")
        st.caption(t(f"acq.mode.{mode}"))
        if mode == "demo":
            st.caption(t("acq.credentials_hint"))
        simulate = False
        if mode == "demo":
            simulate = st.checkbox(t("acq.simulate_interrupt"), key="simulate_interrupt")

        partial = 0 < status["done"] < status["total"]
        label = t("acq.button_resume") if partial else t("acq.button")
        clicked = st.button(label, icon=":material/download:", type="primary", key="btn_download")

        bar = st.progress(status["done"] / status["total"], text=t("acq.progress.label"))
        message = st.empty()
        if not clicked:
            message.caption(t("acq.status.idle") if status["done"] == 0 else
                            t("acq.status.chunk", done=status["done"], total=status["total"]))

        if clicked:
            for ev in dm.iter_acquisition(mode, interrupt_after=6 if simulate else None):
                bar.progress(ev.fraction, text=t("acq.progress.label"))
                if ev.kind == "error":
                    message.error(t("acq.error", detail=ev.detail))
                elif ev.kind in _STATUS_KEYS:
                    message.caption(t(_STATUS_KEYS[ev.kind], done=ev.done, total=ev.total,
                                      files=ev.detail))
            # Une interruption doit laisser le bouton « reprendre » visible : on relit l'état.
            if dm.get_status(mode)["ready"]:
                st.session_state["data_ready"] = True

    ready_mode = dm.get_ready_mode()
    if ready_mode:
        sig = dm.dataset_signature(ready_mode)
        dm.load_dataset(ready_mode)  # préchauffe le cache pour le tableau de bord
        info = dm.dataset_summary(ready_mode, sig)
        st.success(t("acq.summary", months=info["n_months"], start=info["start"], end=info["end"],
                     lat=info["grid"][0], lon=info["grid"][1]), icon=":material/check_circle:")


# --------------------------------------------------------------------------
# 2. Tableau de bord
# --------------------------------------------------------------------------
def render_dashboard() -> None:
    page_header(t("dash.title"), t("dash.subtitle"), "monitoring")

    try:
        ds = dm.load_dataset()
    except FileNotFoundError:
        st.info(t("dash.no_data"), icon=":material/info:")
        return
    sig = dm.dataset_signature(dm.get_ready_mode())
    region = _region_selector()

    # ---- Carte animée ----------------------------------------------------
    with glass_container("dash_map"):
        st.markdown(f"#### :material/map: {t('dash.map.title')}")
        st.caption(t("dash.map.hint"))
        fig = analytics.build_animated_map(
            ds, sig, region, MOISTURE_COLORSCALE, t("dash.map.title"),
            t("dash.map.colorbar"), t("dash.map.time"))
        st.plotly_chart(apply_plotly_theme(fig), width="stretch")

    # ---- Statistiques de tendance ---------------------------------------
    with glass_container("dash_stats"):
        st.markdown(f"#### :material/query_stats: {t('dash.stats.title')}")
        trend = analytics.trend_for_region(ds, sig, region)
        left, right = st.columns([1, 2])
        with left:
            trend_badge(trend.significant, trend.direction)
            st.caption(t("mk.explain.significant" if trend.significant else "mk.explain.not_significant"))
            st.metric(t("mk.p_value"), f"{trend.p_value:.4f}")
            st.metric(t("mk.tau"), f"{trend.tau:+.2f}")
            st.metric(t("mk.slope"), t("mk.slope_unit", value=f"{trend.slope_per_year:+.3f}"))
        with right:
            line = analytics.annual_trend_line(ds, sig, region)
            fig = analytics.trend_figure(line, {
                "title": t("dash.series.title"), "actual": t("dash.series.actual"),
                "fit": t("dash.series.fit"), "axis": t("dash.series.axis")})
            st.plotly_chart(apply_plotly_theme(fig), width="stretch")

        with st.expander(t("glossary.title"), icon=":material/help:"):
            for key in ("soil_moisture", "mann_kendall", "theil_sen"):
                st.markdown(f"- {t(f'glossary.{key}')}")

    # ---- Simulateur What-If ---------------------------------------------
    with glass_container("dash_whatif"):
        st.markdown(f"#### :material/thermostat: {t('whatif.title')}")
        delta = st.slider(t("whatif.slider_short"), 0.5, 4.0, 1.5, 0.5, key="whatif_delta")
        st.markdown(f"**{t('whatif.slider', delta=delta)}**")
        res = analytics.project_whatif(ds, sig, region, delta)

        col_a, col_b = st.columns(2)
        with col_a:
            fig = analytics.whatif_figure(res, "projected", MOISTURE_COLORSCALE,
                                          t("whatif.map.title", delta=delta), t("dash.map.colorbar"))
            st.plotly_chart(apply_plotly_theme(fig), width="stretch")
        with col_b:
            fig = analytics.whatif_figure(res, "change", MOISTURE_COLORSCALE,
                                          t("whatif.map.change"), t("dash.map.colorbar"))
            st.plotly_chart(apply_plotly_theme(fig), width="stretch")
        st.markdown(t("whatif.result", delta=delta, before=f"{res['mean_before']:.1f}",
                      after=f"{res['mean_after']:.1f}"))
        st.caption(t("whatif.disclaimer"))


# --------------------------------------------------------------------------
# 3. Assistant IA (RAG + Glass Box)
# --------------------------------------------------------------------------
def _render_message(msg: dict) -> None:
    """Affiche un message du chat, avec ses sources et son graphique SHAP éventuels."""
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("shap"):
            from src.explainability import plot_waterfall
            st.caption(t("glassbox.caption"))
            st.plotly_chart(apply_plotly_theme(plot_waterfall(msg["shap"])), width="stretch",
                            key=f"shap_{msg['id']}")
        if msg.get("sources"):
            st.caption(f"{t('chat.sources')} : " + ", ".join(msg["sources"]))


def render_assistant() -> None:
    page_header(t("chat.title"), t("chat.subtitle"), "forum")

    try:
        ds = dm.load_dataset()
    except FileNotFoundError:
        st.info(t("dash.no_data"), icon=":material/info:")
        return
    sig = dm.dataset_signature(dm.get_ready_mode())
    region = _region_selector()

    history = st.session_state.setdefault("messages", [])
    top = st.columns([4, 1])
    with top[1]:
        if history and st.button(t("chat.clear"), icon=":material/delete:", key="btn_clear"):
            st.session_state["messages"] = history = []

    # Exemples de questions pour démarrer (aucun message pour l'instant).
    pending = None
    if not history:
        st.caption(t("chat.empty"))
        for i, key in enumerate(("chat.example1", "chat.example2")):
            if st.button(t(key), key=f"example_{i}", icon=":material/chat:"):
                pending = t(key)

    for msg in history:
        _render_message(msg)

    question = st.chat_input(t("chat.placeholder")) or pending
    if not question:
        return

    history.append({"id": len(history), "role": "user", "content": question})
    _render_message(history[-1])

    with st.chat_message("assistant"):
        with st.spinner(t("chat.thinking")):
            reply = _build_reply(ds, sig, region, question, len(history))
        history.append(reply)
    st.rerun()  # redessine l'historique complet, sans doublon


def _build_reply(ds, sig: str, region: str, question: str, msg_id: int) -> dict:
    """Prépare la réponse : texte sourcé (RAG) et, si pertinent, graphique SHAP."""
    from src import explainability, rag_chatbot

    trend = analytics.trend_for_region(ds, sig, region)
    shap_result = explainability.explain_region(ds, sig, region)
    texts = rag_chatbot.build_analysis_texts(t(f"region.{region}"), trend, shap_result)

    try:
        answer = rag_chatbot.answer_question(question, texts)
    except rag_chatbot.MissingLLMKey as exc:
        return {"id": msg_id, "role": "assistant", "content": str(exc)}
    except Exception as exc:  # réseau, quota, modèle indisponible
        return {"id": msg_id, "role": "assistant", "content": t("chat.error", detail=str(exc))}

    reply = {"id": msg_id, "role": "assistant", "content": answer.text, "sources": answer.sources}
    if rag_chatbot.wants_explanation(question):
        # Glass Box : le texte vient du modèle SHAP, pas du modèle de langage.
        reply["content"] += f"\n\n{explainability.explanation_text(shap_result)}"
        reply["shap"] = shap_result
    return reply
