"""
src/analytics.py
================
Calculs statistiques et figures du tableau de bord.

* regional_series()      : série mensuelle moyenne d'une zone (pondérée par la surface)
* analyze_trend()        : test de Mann-Kendall saisonnier + pente de Theil-Sen
* annual_trend_line()    : moyennes annuelles + droite de Theil-Sen pour le graphique
* build_animated_map()   : carte Plotly animée (curseur temporel) de l'humidité du sol
* temperature_sensitivity(), project_whatif(), whatif_figure() : simulateur What-If

Convention de cache
-------------------
Les fonctions lourdes sont décorées par @st.cache_data. Le jeu xarray est passé dans un
argument préfixé par "_" (ignoré par le hachage de Streamlit, trop coûteux sur ~60 Mo) ;
c'est l'argument `signature` (voir data_manager.dataset_signature) qui invalide le cache
quand les données changent.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import pymannkendall as mk
import streamlit as st
import xarray as xr
from scipy import stats

ALPHA = 0.05  # seuil de significativité

# Zones d'étude : (lat_min, lat_max, lon_min, lon_max)
REGIONS: dict[str, tuple[float, float, float, float]] = {
    "africa": (-34.0, 36.0, -18.0, 50.0),
    "sahel": (10.0, 18.0, -18.0, 50.0),
    "southern_africa": (-30.0, -15.0, 15.0, 35.0),
    "cameroon": (2.0, 13.0, 8.0, 16.0),
}


# --------------------------------------------------------------------------
# Outils de base
# --------------------------------------------------------------------------
def select_region(ds: xr.Dataset, region: str) -> xr.Dataset:
    """Découpe le jeu de données sur la zone demandée (latitudes triées croissantes)."""
    lat0, lat1, lon0, lon1 = REGIONS[region]
    return ds.sel(lat=slice(lat0, lat1), lon=slice(lon0, lon1))


def area_weighted_mean(da: xr.DataArray) -> xr.DataArray:
    """Moyenne spatiale pondérée par cos(latitude) : les mailles polaires pèsent moins."""
    weights = np.cos(np.deg2rad(da.lat))
    return da.weighted(weights).mean(("lat", "lon"))


# --------------------------------------------------------------------------
# Séries et tendance
# --------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def regional_series(_ds: xr.Dataset, signature: str, region: str,
                    variable: str = "soil_moisture") -> pd.Series:
    """Série mensuelle de la moyenne régionale d'une variable."""
    da = area_weighted_mean(select_region(_ds, region)[variable])
    return da.to_series().rename(variable)


@dataclass(frozen=True)
class TrendResult:
    """Résultat du test de tendance, directement affichable."""
    p_value: float
    tau: float
    slope_per_year: float     # pente de Theil-Sen, unités de la variable par an
    direction: str            # "decreasing" | "increasing" | "no_trend"
    significant: bool         # p < ALPHA
    n_months: int


def analyze_trend(series: pd.Series) -> TrendResult:
    """
    Test de Mann-Kendall saisonnier (période de 12 mois), qui compare chaque mois à
    lui-même d'une année sur l'autre. C'est le test adapté à des données mensuelles :
    le cycle saisonnier ne peut pas être pris pour une tendance.
    La pente de Theil-Sen (médiane des pentes entre paires de points) est exprimée par an.
    """
    values = series.dropna().to_numpy()
    if len(values) < 24:
        raise ValueError("Au moins 24 mois de données sont nécessaires.")
    res = mk.seasonal_test(values, period=12, alpha=ALPHA)
    direction = {"decreasing": "decreasing", "increasing": "increasing"}.get(res.trend, "no_trend")
    significant = bool(res.p < ALPHA)
    return TrendResult(
        p_value=float(res.p),
        tau=float(res.Tau),
        slope_per_year=float(res.slope),  # seasonal_test rend déjà une pente par an (vérifié)
        direction=direction if significant else "no_trend",
        significant=significant,
        n_months=len(values),
    )


@st.cache_data(show_spinner=False)
def trend_for_region(_ds: xr.Dataset, signature: str, region: str) -> TrendResult:
    """Tendance de l'humidité du sol sur une zone (version mise en cache)."""
    return analyze_trend(regional_series(_ds, signature, region))


@st.cache_data(show_spinner=False)
def annual_trend_line(_ds: xr.Dataset, signature: str, region: str) -> pd.DataFrame:
    """
    Moyennes annuelles de l'humidité du sol et droite de Theil-Sen ajustée dessus.
    Colonnes : year, value, fit.
    """
    s = regional_series(_ds, signature, region).dropna()
    annual = s.groupby(s.index.year).mean()
    years = annual.index.to_numpy(dtype=float)
    slope, intercept, _, _ = stats.theilslopes(annual.to_numpy(), years)
    return pd.DataFrame({"year": annual.index, "value": annual.to_numpy(),
                         "fit": intercept + slope * years})


def trend_figure(line: pd.DataFrame, labels: dict[str, str]) -> go.Figure:
    """Graphique des moyennes annuelles et de la pente de Theil-Sen (thème appliqué ensuite)."""
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=line["year"], y=line["value"], mode="lines+markers",
                             name=labels["actual"], line=dict(color="#00E5FF", width=2)))
    fig.add_trace(go.Scatter(x=line["year"], y=line["fit"], mode="lines",
                             name=labels["fit"], line=dict(color="#FF3D00", width=2, dash="dash")))
    fig.update_layout(title=labels["title"], yaxis_title=labels["axis"], hovermode="x unified",
                      legend=dict(orientation="h", y=-0.2))
    return fig


# --------------------------------------------------------------------------
# Carte animée
# --------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def build_animated_map(_ds: xr.Dataset, signature: str, region: str, colorscale: list,
                       title: str, colorbar_title: str, frame_label: str) -> go.Figure:
    """
    Carte animée de l'humidité du sol : une image par année (moyenne annuelle), avec un
    curseur temporel et un bouton lecture. L'échelle de couleur est fixe sur toute
    l'animation, sinon les images ne seraient pas comparables entre elles.
    """
    da = select_region(_ds, region)["soil_moisture"].groupby("time.year").mean("time")
    arr = da.to_numpy()
    fig = px.imshow(
        arr,
        x=da.lon.to_numpy(), y=da.lat.to_numpy(),
        animation_frame=0, origin="lower", aspect="auto",
        color_continuous_scale=colorscale,
        zmin=float(np.nanpercentile(arr, 2)), zmax=float(np.nanpercentile(arr, 98)),
        labels={"color": colorbar_title, "x": "lon", "y": "lat"},
    )
    # px numérote les images 0, 1, 2... : on affiche les années à la place.
    years = da.year.to_numpy()
    for step, year in zip(fig.layout.sliders[0].steps, years):
        step.label = str(int(year))
    fig.layout.sliders[0].currentvalue.prefix = f"{frame_label} : "
    fig.update_layout(title=title, coloraxis_colorbar_title=colorbar_title, height=520)
    return fig


# --------------------------------------------------------------------------
# Simulateur What-If (régression linéaire)
# --------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def temperature_sensitivity(_ds: xr.Dataset, signature: str, region: str) -> xr.DataArray:
    """
    Sensibilité locale de l'humidité du sol à la température (kg/m² par °C).

    Pour chaque maille, régression linéaire des anomalies mensuelles :
        humidité = b_T * température + b_P * précipitations + erreur
    On garde b_T : l'effet de la température à précipitations constantes.
    Les anomalies (écart au cycle saisonnier) évitent de confondre saison et climat.
    """
    sub = select_region(_ds, region)[["soil_moisture", "temperature", "precipitation"]]
    clim = sub.groupby("time.month").mean("time")
    anom = sub.groupby("time.month") - clim
    s = anom["soil_moisture"].to_numpy()
    t_ = anom["temperature"].to_numpy()
    p_ = anom["precipitation"].to_numpy()

    out = np.full(s.shape[1:], np.nan)
    for i in range(s.shape[1]):
        for j in range(s.shape[2]):
            x = np.column_stack([t_[:, i, j], p_[:, i, j]])
            y = s[:, i, j]
            ok = np.isfinite(x).all(axis=1) & np.isfinite(y)
            if ok.sum() > 24:
                out[i, j] = np.linalg.lstsq(x[ok], y[ok], rcond=None)[0][0]
    return xr.DataArray(out, coords={"lat": sub.lat, "lon": sub.lon}, dims=("lat", "lon"),
                        name="sensitivity")


@st.cache_data(show_spinner=False)
def project_whatif(_ds: xr.Dataset, signature: str, region: str, delta_t: float,
                   baseline_months: int = 36) -> dict:
    """
    Projette l'humidité du sol pour un réchauffement `delta_t` (°C).
    projection = moyenne récente + sensibilité * delta_t   (bornée à zéro)
    Retourne baseline, projected, change (DataArray) et les moyennes régionales.
    """
    sub = select_region(_ds, region)
    sens = temperature_sensitivity(_ds, signature, region)
    baseline = sub["soil_moisture"].isel(time=slice(-baseline_months, None)).mean("time")
    projected = (baseline + sens * delta_t).clip(min=0)
    change = projected - baseline
    return {
        "baseline": baseline, "projected": projected, "change": change,
        "mean_before": float(area_weighted_mean(baseline)),
        "mean_after": float(area_weighted_mean(projected)),
        "delta_t": float(delta_t),
    }


def whatif_figure(result: dict, kind: str, colorscale: list, title: str,
                  colorbar_title: str) -> go.Figure:
    """
    Carte du simulateur. kind="projected" : humidité projetée, sur la même échelle que le
    présent ; kind="change" : variation par rapport au présent (centrée sur zéro).
    """
    if kind == "projected":
        base = result["baseline"].to_numpy()
        da = result["projected"]
        kwargs = dict(zmin=float(np.nanpercentile(base, 2)), zmax=float(np.nanpercentile(base, 98)),
                      color_continuous_scale=colorscale)
    else:
        da = result["change"]
        lim = float(np.nanmax(np.abs(da.to_numpy()))) or 1.0
        kwargs = dict(zmin=-lim, zmax=lim, color_continuous_scale=colorscale)
    fig = px.imshow(da.to_numpy(), x=da.lon.to_numpy(), y=da.lat.to_numpy(), origin="lower",
                    aspect="auto", labels={"color": colorbar_title, "x": "lon", "y": "lat"}, **kwargs)
    fig.update_layout(title=title, height=420)
    return fig
