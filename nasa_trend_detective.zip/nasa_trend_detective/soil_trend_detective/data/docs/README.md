# Documents de l'assistant

Déposez ici les documents (.md, .txt, .pdf) que l'assistant peut citer : guides GLDAS et
MERRA-2, articles sur le stress hydrique, notes méthodologiques.
Sans document, l'assistant ne s'appuie que sur les résultats calculés par l'application.
