"""
src/explainability.py
=====================
"Glass Box AI" : explique visuellement pourquoi le sol d'une zone est sec.
"""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
import shap
import streamlit as st
import xarray as xr
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split

from src.analytics import select_region
from src.i18n import t, get_language  # <-- IMPORT DE get_language

POSSIBLE_FEATURES = ("evapotranspiration", "precipitation", "temperature", "runoff", "aerosol")

# Libellés de repli (FR, EN) si la clé "factor.<nom>" manque dans i18n.py (ex. aérosols).
_FACTOR_FALLBACK = {
    "evapotranspiration": ("Évapotranspiration", "Evapotranspiration"),
    "precipitation": ("Précipitations", "Precipitation"),
    "temperature": ("Température", "Temperature"),
    "runoff": ("Ruissellement", "Runoff"),
    "aerosol": ("Aérosols", "Aerosols"),
}

# Rôle physique de chaque variable (FR, EN), utilisé dans le texte d'explication.
_MECHANISM = {
    "evapotranspiration": ("l'eau du sol retourne à l'atmosphère par évaporation et transpiration des plantes",
                           "soil water returns to the atmosphere through evaporation and plant transpiration"),
    "precipitation": ("la pluie est le principal apport d'eau : moins de pluie, moins de recharge",
                      "rain is the main water input: less rain means less recharge"),
    "temperature": ("la chaleur augmente la demande évaporative de l'air et accélère l'assèchement",
                    "heat raises the air's evaporative demand and speeds up drying"),
    "runoff": ("l'eau qui ruisselle en surface ne s'infiltre pas et ne recharge pas le sol",
               "water running off the surface does not infiltrate and recharge the soil"),
    "aerosol": ("les particules modifient le rayonnement et les nuages, avec un effet indirect et incertain sur l'humidité",
                "particles alter radiation and clouds, with an indirect and uncertain effect on moisture"),
}


def _factor_label(name: str) -> str:
    """Libellé traduit ; retombe sur un libellé local si la clé i18n n'existe pas."""
    label = t(f"factor.{name}")
    if label.startswith("factor."):
        fr, en = _FACTOR_FALLBACK.get(name, (name, name))
        return fr if get_language() == "fr" else en
    return label
TARGET = "soil_moisture"
MAX_SAMPLES = 20_000
RECENT_MONTHS = 12

@st.cache_data(show_spinner=False)
def explain_region(_ds: xr.Dataset, signature: str, region: str) -> dict | None:
    sub = select_region(_ds, region)
    available_features = [f for f in POSSIBLE_FEATURES if f in sub.data_vars]
    
    if not available_features or TARGET not in sub.data_vars:
        return None

    x = np.column_stack([sub[f].to_numpy().ravel() for f in available_features])
    y = sub[TARGET].to_numpy().ravel()
    
    ok = np.isfinite(x).all(axis=1) & np.isfinite(y)
    x, y = x[ok], y[ok]

    if len(y) < 50:
        return None

    rng = np.random.default_rng(0)
    if len(y) > MAX_SAMPLES:
        pick = rng.choice(len(y), MAX_SAMPLES, replace=False)
        x, y = x[pick], y[pick]

    x_tr, x_te, y_tr, y_te = train_test_split(x, y, test_size=0.2, random_state=0)
    model = RandomForestRegressor(n_estimators=80, max_depth=10, min_samples_leaf=5,
                                  n_jobs=-1, random_state=0).fit(x_tr, y_tr)
    r2 = float(r2_score(y_te, model.predict(x_te)))

    recent = sub.isel(time=slice(-RECENT_MONTHS, None))
    instance = np.array([[float(recent[f].mean()) for f in available_features]])

    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(instance)[0]
    base = float(np.ravel(explainer.expected_value)[0])

    contributions = {f: float(v) for f, v in zip(available_features, shap_values)}
    total = sum(abs(v) for v in contributions.values()) or 1.0
    
    return {
        "base_value": base,
        "prediction": base + float(sum(contributions.values())),
        "contributions": contributions,
        "shares": {f: 100.0 * abs(v) / total for f, v in contributions.items()},
        "feature_values": {f: float(instance[0, i]) for i, f in enumerate(available_features)},
        "r2": r2,
    }

def plot_waterfall(result: dict) -> go.Figure:
    if not result:
        return go.Figure()

    ordered = sorted(result["contributions"].items(), key=lambda kv: abs(kv[1]), reverse=True)
    labels = [t("glassbox.baseline")] + [_factor_label(name) for name, _ in ordered] + [t("glassbox.prediction")]
    values = [result["base_value"]] + [v for _, v in ordered] + [0]
    measures = ["absolute"] + ["relative"] * len(ordered) + ["total"]
    texts = [f"{result['base_value']:.1f}"] + [f"{v:+.2f}" for _, v in ordered] + [f"{result['prediction']:.1f}"]

    fig = go.Figure(go.Waterfall(
        orientation="h", measure=measures, y=labels, x=values, text=texts, textposition="outside",
        connector=dict(line=dict(color="rgba(255,255,255,0.25)")),
        increasing=dict(marker=dict(color="#00E5FF")),
        decreasing=dict(marker=dict(color="#FF3D00")),
        totals=dict(marker=dict(color="#8A97AD")),
    ))
    fig.update_layout(
        title=t("glassbox.title"),
        xaxis_title=t("dash.series.axis"),
        yaxis=dict(autorange="reversed"),
        height=300, showlegend=False,
    )
    return fig

def explanation_parts(result: dict, top: int = 3) -> str:
    if not result:
        return ""
    ranked = sorted(result["shares"].items(), key=lambda kv: kv[1], reverse=True)[:top]
    return ", ".join(f"{_factor_label(name)} {share:.0f} %" for name, share in ranked)

# --- Explication pilotée par les résultats SHAP ---
def explanation_text(result: dict) -> str:
    """
    Explication de secours (sans modèle de langage), construite à partir des valeurs SHAP :
    facteurs classés, sens de leur effet, mécanisme physique, impacts si le sol est sec.
    """
    if not result:
        return ""
    fr = get_language() == "fr"
    pred, base = result["prediction"], result["base_value"]
    dry = pred < base
    ranked = sorted(result["contributions"].items(), key=lambda kv: abs(kv[1]), reverse=True)[:3]

    lines = []
    if fr:
        lines.append("**Ce que montre l'analyse SHAP**")
        lines.append(f"Sur les 12 derniers mois, l'humidité du sol est estimée à **{pred:.1f} kg/m²**, "
                     f"contre {base:.1f} kg/m² en moyenne pour le modèle "
                     f"({'situation plus sèche que la moyenne' if dry else 'situation pas plus sèche que la moyenne'}).")
        lines.append("\n**Facteurs principaux**")
        for name, contrib in ranked:
            effect = "assèche" if contrib < 0 else "humidifie"
            lines.append(f"- **{_factor_label(name)}** ({result['shares'][name]:.0f} %) : {effect} "
                         f"({contrib:+.2f} kg/m²). Mécanisme : {_MECHANISM[name][0]}.")
        if dry:
            lines.append("\n**Impacts possibles d'un sol durablement sec**")
            lines.append("- Agriculture : baisse des rendements, besoin accru d'irrigation.")
            lines.append("- Élevage : raréfaction des points d'eau et du fourrage.")
            lines.append("- Ressources en eau : sollicitation accrue des nappes phréatiques.")
        lines.append(f"\nSHAP décrit comment le modèle associe les variables à l'humidité du sol, "
                     f"pas une preuve de causalité (R² du modèle : {result['r2']:.2f}).")
    else:
        lines.append("**What the SHAP analysis shows**")
        lines.append(f"Over the last 12 months, soil moisture is estimated at **{pred:.1f} kg/m²**, "
                     f"versus a model average of {base:.1f} kg/m² "
                     f"({'drier than average' if dry else 'not drier than average'}).")
        lines.append("\n**Main factors**")
        for name, contrib in ranked:
            effect = "dries the soil" if contrib < 0 else "wets the soil"
            lines.append(f"- **{_factor_label(name)}** ({result['shares'][name]:.0f}%): {effect} "
                         f"({contrib:+.2f} kg/m²). Mechanism: {_MECHANISM[name][1]}.")
        if dry:
            lines.append("\n**Possible impacts of lasting dry soil**")
            lines.append("- Agriculture: lower yields, greater irrigation needs.")
            lines.append("- Livestock: scarcer water points and fodder.")
            lines.append("- Water resources: heavier pressure on groundwater.")
        lines.append(f"\nSHAP describes how the model links variables to soil moisture, "
                     f"not proof of causation (model R²: {result['r2']:.2f}).")
    return "\n".join(lines)
