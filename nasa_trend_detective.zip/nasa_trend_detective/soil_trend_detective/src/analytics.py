"""
src/analytics.py
================
Calculs statistiques et figures du tableau de bord.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import pymannkendall as mk
import streamlit as st
import xarray as xr
from scipy import stats
from scipy.interpolate import griddata

ALPHA = 0.05  # seuil de significativité

REGIONS: dict[str, tuple[float, float, float, float]] = {
    "africa": (-34.0, 36.0, -18.0, 50.0),
    "sahel": (10.0, 18.0, -18.0, 50.0),
    "southern_africa": (-30.0, -15.0, 15.0, 35.0),
    "cameroon": (2.0, 13.0, 8.0, 16.0),
}


def select_region(ds: xr.Dataset, region: str) -> xr.Dataset:
    if region == "custom" or "lat" not in ds.dims or len(ds.lat) <= 1:
        return ds
    lat0, lat1, lon0, lon1 = REGIONS[region]
    return ds.sel(lat=slice(lat0, lat1), lon=slice(lon0, lon1))


def area_weighted_mean(da: xr.DataArray) -> xr.DataArray:
    if "lat" not in da.dims or len(da.lat) <= 1:
        return da.mean(("lat", "lon"))
    weights = np.cos(np.deg2rad(da.lat))
    return da.weighted(weights).mean(("lat", "lon"))


@st.cache_data(show_spinner=False)
def regional_series(_ds: xr.Dataset, signature: str, region: str,
                    variable: str = "soil_moisture") -> pd.Series:
    da = area_weighted_mean(select_region(_ds, region)[variable])
    return da.to_series().rename(variable)


@dataclass(frozen=True)
class TrendResult:
    p_value: float
    tau: float
    slope_per_year: float
    direction: str
    significant: bool
    n_months: int


def analyze_trend(series: pd.Series) -> TrendResult:
    values = series.dropna().to_numpy()
    
    if len(values) < 12:
        return TrendResult(p_value=1.0, tau=0.0, slope_per_year=0.0, direction="no_trend", significant=False, n_months=len(values))
        
    if len(values) < 24:
        res = mk.original_test(values, alpha=ALPHA)
    else:
        res = mk.seasonal_test(values, period=12, alpha=ALPHA)

    direction = {"decreasing": "decreasing", "increasing": "increasing"}.get(res.trend, "no_trend")
    significant = bool(res.p < ALPHA)
    
    return TrendResult(
        p_value=float(res.p),
        tau=float(res.Tau),
        slope_per_year=float(res.slope), 
        direction=direction if significant else "no_trend",
        significant=significant,
        n_months=len(values),
    )


@st.cache_data(show_spinner=False)
def trend_for_region(_ds: xr.Dataset, signature: str, region: str) -> TrendResult:
    return analyze_trend(regional_series(_ds, signature, region))


@st.cache_data(show_spinner=False)
def annual_trend_line(_ds: xr.Dataset, signature: str, region: str) -> pd.DataFrame:
    s = regional_series(_ds, signature, region).dropna()
    annual = s.groupby(s.index.year).mean()
    years = annual.index.to_numpy(dtype=float)
    slope, intercept, _, _ = stats.theilslopes(annual.to_numpy(), years)
    return pd.DataFrame({"year": annual.index, "value": annual.to_numpy(),
                         "fit": intercept + slope * years})


def trend_figure(line: pd.DataFrame, labels: dict[str, str]) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=line["year"], y=line["value"], mode="lines+markers",
                             name=labels["actual"], line=dict(color="#00E5FF", width=2)))
    fig.add_trace(go.Scatter(x=line["year"], y=line["fit"], mode="lines",
                             name=labels["fit"], line=dict(color="#FF3D00", width=2, dash="dash")))
    fig.update_layout(title=labels["title"], yaxis_title=labels["axis"], hovermode="x unified",
                      legend=dict(orientation="h", y=-0.2))
    return fig


@st.cache_data(show_spinner=False)
def plot_raw_timeseries(_ds: xr.Dataset, signature: str, region: str) -> go.Figure:
    s = regional_series(_ds, signature, region).dropna()
    rolling = s.rolling(window=12, center=True).mean()

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=s.index, y=s.values, mode="lines", name="Mensuel",
                             line=dict(color="rgba(0, 229, 255, 0.3)", width=1)))
    fig.add_trace(go.Scatter(x=rolling.index, y=rolling.values, mode="lines", name="Moyenne mobile (12m)",
                             line=dict(color="#00E5FF", width=3)))
    fig.update_layout(title="Série Temporelle (Brute)", yaxis_title="Humidité (kg/m²)", height=300)
    return fig


# --------------------------------------------------------------------------
# FONCTION D'INTERPOLATION POUR ÉVITER L'EFFET "MONTICULE"
# --------------------------------------------------------------------------
def _interpolate_grid(df: pd.DataFrame, val_col: str, res: int = 80) -> pd.DataFrame:
    """Interpole une grille grossière pour créer une nappe continue (heatmap)."""
    if len(df) < 4 or val_col not in df.columns:
        return df
        
    lat_min, lat_max = df["lat"].min(), df["lat"].max()
    lon_min, lon_max = df["lon"].min(), df["lon"].max()
    
    # On ajoute une petite marge pour éviter les bords vides
    lat_min -= 0.5; lat_max += 0.5
    lon_min -= 0.5; lon_max += 0.5
    
    lat_dense = np.linspace(lat_min, lat_max, res)
    lon_dense = np.linspace(lon_min, lon_max, res)
    lon_grid, lat_grid = np.meshgrid(lon_dense, lat_dense)
    
    # Interpolation cubique pour un rendu lisse
    grid_values = griddata(
        (df["lon"], df["lat"]), df[val_col],
        (lon_grid, lat_grid), method="cubic"
    )
    
    dense_df = pd.DataFrame({
        "lat": lat_grid.flatten(),
        "lon": lon_grid.flatten(),
        val_col: grid_values.flatten()
    }).dropna()
    
    return dense_df


# --------------------------------------------------------------------------
# CARTES INTERACTIVES (MapLibre + Heatmap continue)
# --------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def build_animated_map(_ds: xr.Dataset, signature: str, region: str, colorscale: list,
                       title: str, colorbar_title: str, frame_label: str) -> go.Figure:
    """Carte géographique animée avec effet de chaleur continu."""
    da = select_region(_ds, region)["soil_moisture"].groupby("time.year").mean("time")
    df = da.to_dataframe(name="value").reset_index().dropna(subset=["value"])
    
    # Interpolation année par année pour un rendu lisse
    dense_dfs = []
    for year in df['year'].unique():
        sub_df = df[df['year'] == year]
        dense_df = _interpolate_grid(sub_df, "value", res=60)
        dense_df['year'] = year
        dense_dfs.append(dense_df)
        
    dense_df_all = pd.concat(dense_dfs)
    
    fig = px.scatter_map(
        dense_df_all,
        lat="lat",
        lon="lon",
        color="value",
        animation_frame="year",
        color_continuous_scale=colorscale,
        map_style="carto-darkmatter",
        zoom=2,
        center={"lat": dense_df_all["lat"].mean(), "lon": dense_df_all["lon"].mean()},
        labels={"value": colorbar_title, "year": frame_label},
        title=title
    )
    
    fig.update_traces(
        marker=dict(size=6, opacity=0.8),
        hovertemplate=(
            "<b>Latitude</b>: %{lat:.2f}<br>"
            "<b>Longitude</b>: %{lon:.2f}<br>"
            f"<b>{colorbar_title}</b>: %{{marker.color:.2f}}<extra></extra>"
        )
    )
    
    fig.update_layout(
        height=550, margin=dict(l=0, r=0, t=40, b=0),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        hoverlabel=dict(bgcolor="#121826", font_size=14, font_family="Inter")
    )
    return fig


@st.cache_data(show_spinner=False)
def build_trend_map(_ds: xr.Dataset, signature: str, region: str, colorscale: list) -> go.Figure:
    """Carte géographique des tendances avec effet de chaleur continu."""
    sub = select_region(_ds, region)["soil_moisture"]
    annual = sub.groupby("time.year").mean("time")
    years = annual.year.values
    
    slopes = xr.apply_ufunc(
        lambda y: np.polyfit(years, y, 1)[0] if np.isfinite(y).all() else np.nan,
        annual, input_core_dims=[["year"]], vectorize=True, dask="parallelized", output_dtypes=[float]
    )
    
    df = slopes.to_dataframe(name="trend").reset_index().dropna()
    dense_df = _interpolate_grid(df, "trend", res=80)
    
    fig = px.scatter_map(
        dense_df, 
        lat="lat", 
        lon="lon", 
        color="trend", 
        color_continuous_scale="RdBu", 
        range_color=(-0.2, 0.2), 
        map_style="carto-darkmatter",
        zoom=2,
        center={"lat": dense_df["lat"].mean(), "lon": dense_df["lon"].mean()},
        labels={"trend": "Tendance (kg/m²/an)"}, 
        title="Carte des Tendances Spatiales (Theil-Sen)"
    )
    
    fig.update_traces(
        marker=dict(size=8, opacity=0.8),
        hovertemplate=(
            "<b>Latitude</b>: %{lat:.2f}<br>"
            "<b>Longitude</b>: %{lon:.2f}<br>"
            "<b>Tendance</b>: %{marker.color:.4f} kg/m²/an<extra></extra>"
        )
    )
    
    fig.update_layout(
        height=500, margin=dict(l=0, r=0, t=40, b=0),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        hoverlabel=dict(bgcolor="#121826", font_size=14, font_family="Inter")
    )
    return fig


# --------------------------------------------------------------------------
# Simulateur What-If
# --------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def temperature_sensitivity(_ds: xr.Dataset, signature: str, region: str) -> xr.DataArray:
    sub = select_region(_ds, region)[["soil_moisture", "temperature", "precipitation"]]
    clim = sub.groupby("time.month").mean("time")
    anom = sub.groupby("time.month") - clim
    s = anom["soil_moisture"].to_numpy()
    t_ = anom["temperature"].to_numpy()
    p_ = anom["precipitation"].to_numpy()

    out = np.full(s.shape[1:], np.nan)
    for i in range(s.shape[1]):
        for j in range(s.shape[2]):
            x = np.column_stack([t_[:, i, j], p_[:, i, j]])
            y = s[:, i, j]
            ok = np.isfinite(x).all(axis=1) & np.isfinite(y)
            if ok.sum() > 24:
                out[i, j] = np.linalg.lstsq(x[ok], y[ok], rcond=None)[0][0]
    return xr.DataArray(out, coords={"lat": sub.lat, "lon": sub.lon}, dims=("lat", "lon"),
                        name="sensitivity")


@st.cache_data(show_spinner=False)
def project_whatif(_ds: xr.Dataset, signature: str, region: str, delta_t: float,
                   baseline_months: int = 36) -> dict:
    sub = select_region(_ds, region)
    sens = temperature_sensitivity(_ds, signature, region)
    baseline = sub["soil_moisture"].isel(time=slice(-baseline_months, None)).mean("time")
    projected = (baseline + sens * delta_t).clip(min=0)
    change = projected - baseline
    return {
        "baseline": baseline, "projected": projected, "change": change,
        "mean_before": float(area_weighted_mean(baseline)),
        "mean_after": float(area_weighted_mean(projected)),
        "delta_t": float(delta_t),
    }


def whatif_figure(result: dict, kind: str, colorscale: list, title: str,
                  colorbar_title: str) -> go.Figure:
    if kind == "projected":
        da = result["projected"]
        df = da.to_dataframe(name="value").reset_index()
        dense_df = _interpolate_grid(df, "value", res=80)
        fig = px.scatter_map(dense_df, lat="lat", lon="lon", color="value",
                             color_continuous_scale=colorscale, map_style="carto-darkmatter",
                             zoom=2, center={"lat": dense_df["lat"].mean(), "lon": dense_df["lon"].mean()},
                             labels={"value": colorbar_title})
        hover_text = "<b>Humidité projetée</b>: %{marker.color:.2f} kg/m²<extra></extra>"
    else:
        da = result["change"]
        df = da.to_dataframe(name="change").reset_index()
        dense_df = _interpolate_grid(df, "change", res=80)
        fig = px.scatter_map(dense_df, lat="lat", lon="lon", color="change", 
                             color_continuous_scale="RdBu", range_color=(-5, 5), 
                             map_style="carto-darkmatter", zoom=2,
                             center={"lat": dense_df["lat"].mean(), "lon": dense_df["lon"].mean()},
                             labels={"change": "Variation"})
        hover_text = "<b>Variation</b>: %{marker.color:+.2f} kg/m²<extra></extra>"
        
    fig.update_traces(
        marker=dict(size=8, opacity=0.8),
        hovertemplate="<b>Lat</b>: %{lat:.2f}, <b>Lon</b>: %{lon:.2f}<br>" + hover_text
    )
    
    fig.update_layout(title=title, height=420, margin=dict(l=0, r=0, t=40, b=0),
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      hoverlabel=dict(bgcolor="#121826", font_size=14, font_family="Inter"))
    return fig
