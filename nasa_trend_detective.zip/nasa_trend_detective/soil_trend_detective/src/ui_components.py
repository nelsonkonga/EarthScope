"""
src/ui_components.py
====================
Composants d'interface pour Soil Trend Detective : thème "Scientific Observatory".

Contenu
-------
* Constantes de design (palette, colorscale, thème Plotly)
* inject_css()              : CSS global (thème sombre, glassmorphism, widgets)
* init_session_state()      : valeurs par défaut (langue, vue, page)
* language_selector()       : bascule FR / EN, disponible sur la landing et la sidebar
* render_landing()          : page d'accueil plein écran
* render_sidebar()          : navigation du workspace, retourne la page active
* glass_container(), feature_card(), page_header(), trend_badge() : briques réutilisables
* apply_plotly_theme()      : applique le thème sombre aux figures Plotly

Prérequis : Streamlit >= 1.50 (conteneurs avec `key`, `st.button(icon=..., width=...)`).
Règle de design : aucun emoji, uniquement les icônes Material (:material/nom:).
"""

from __future__ import annotations

import html
import math

import streamlit as st

from src.i18n import LANGUAGE_LABELS, LANGUAGES, SESSION_KEY, get_language, set_language, t

# --------------------------------------------------------------------------
# Design tokens
# --------------------------------------------------------------------------
COLORS = {
    "bg": "#0B0F19",          # fond profond
    "surface": "#121826",     # surfaces opaques (menus, tooltips)
    "text": "#E6EDF7",
    "muted": "#8A97AD",
    "cyan": "#00E5FF",        # accent principal
    "red": "#FF3D00",         # alerte : assèchement
    "green": "#00E676",       # tendance à l'humidification
}

# Du sec (rouge) vers l'humide (cyan), en passant par un neutre sombre.
MOISTURE_COLORSCALE = [
    [0.0, "#FF3D00"],
    [0.35, "#7A2A12"],
    [0.5, "#1B2335"],
    [0.65, "#0A6F80"],
    [1.0, "#00E5FF"],
]

# Pages du workspace, dans l'ordre de la navigation.
PAGES = ("acquisition", "dashboard", "assistant")
PAGE_ICONS = {
    "acquisition": "cloud_download",
    "dashboard": "monitoring",
    "assistant": "forum",
}


# --------------------------------------------------------------------------
# Session
# --------------------------------------------------------------------------
def init_session_state() -> None:
    """Initialise les clés de session. À appeler une fois en haut de app.py."""
    st.session_state.setdefault(SESSION_KEY, "fr")
    st.session_state.setdefault("view", "landing")        # "landing" | "workspace"
    st.session_state.setdefault("page", PAGES[0])


def _enter_workspace() -> None:
    st.session_state["view"] = "workspace"


def _go_home() -> None:
    st.session_state["view"] = "landing"


def _go_page(page: str) -> None:
    st.session_state["page"] = page


def _on_language_change(widget_key: str) -> None:
    """Callback : propage le choix du widget vers l'état global de langue."""
    set_language(st.session_state[widget_key])


# --------------------------------------------------------------------------
# CSS
# --------------------------------------------------------------------------
_BASE_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600&family=Sora:wght@500;600;700&display=swap');

:root {
  --bg: #0B0F19;
  --surface: #121826;
  --text: #E6EDF7;
  --muted: #8A97AD;
  --cyan: #00E5FF;
  --red: #FF3D00;
  --green: #00E676;
  --glass: rgba(255, 255, 255, 0.045);
  --glass-strong: rgba(255, 255, 255, 0.075);
  --glass-border: rgba(0, 229, 255, 0.18);
  --radius: 20px;
  --font-display: 'Sora', 'Segoe UI', system-ui, sans-serif;
  --font-body: 'Instrument Sans', 'Segoe UI', system-ui, sans-serif;
}

/* ---- Fond et typographie globale --------------------------------------- */
[data-testid="stAppViewContainer"], .stApp {
  background:
    radial-gradient(1100px 600px at 12% -10%, rgba(0, 229, 255, 0.10), transparent 60%),
    radial-gradient(900px 600px at 100% 100%, rgba(255, 61, 0, 0.08), transparent 60%),
    var(--bg);
  color: var(--text);
  font-family: var(--font-body);
}
[data-testid="stHeader"] { background: transparent; }
[data-testid="stMainBlockContainer"] { max-width: 1180px; padding-top: 2.5rem; }

h1, h2, h3, h4 {
  font-family: var(--font-display);
  letter-spacing: -0.01em;
  color: var(--text);
}
p, li, label, .stMarkdown { font-family: var(--font-body); line-height: 1.6; }
.stCaption, [data-testid="stCaptionContainer"] { color: var(--muted); }

/* ---- Glassmorphism ------------------------------------------------------ */
[class*="st-key-glass"],
[data-testid="stExpander"],
[data-testid="stChatMessage"] {
  background: var(--glass);
  border: 1px solid var(--glass-border);
  border-radius: var(--radius);
  -webkit-backdrop-filter: blur(16px) saturate(140%);
  backdrop-filter: blur(16px) saturate(140%);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.05);
  padding: 1.1rem 1.25rem;
}
[class*="st-key-glass"] h4 { margin-top: 0; }
[data-testid="stExpander"] details { border: none; }

/* ---- Sidebar ------------------------------------------------------------ */
[data-testid="stSidebar"] {
  background: rgba(11, 15, 25, 0.78);
  -webkit-backdrop-filter: blur(18px);
  backdrop-filter: blur(18px);
  border-right: 1px solid var(--glass-border);
}
[data-testid="stSidebar"] .stButton > button {
  justify-content: flex-start;
  text-align: left;
  padding: 0.65rem 0.9rem;
}

/* ---- Boutons ------------------------------------------------------------ */
.stButton > button, .stDownloadButton > button {
  font-family: var(--font-body);
  font-weight: 500;
  border-radius: 14px;
  border: 1px solid var(--glass-border);
  background: var(--glass);
  color: var(--text);
  transition: background 0.18s ease, border-color 0.18s ease, color 0.18s ease;
}
.stButton > button:hover { border-color: var(--cyan); color: var(--cyan); background: var(--glass-strong); }
.stButton > button[kind="primary"] {
  background: rgba(0, 229, 255, 0.14);
  border-color: var(--cyan);
  color: var(--cyan);
}
.stButton > button[kind="primary"]:hover { background: var(--cyan); color: var(--bg); }

/* ---- Champs, curseurs, progression ------------------------------------- */
[data-testid="stTextInput"] input, [data-testid="stChatInput"] textarea, [data-baseweb="select"] > div {
  background: var(--glass) !important;
  color: var(--text) !important;
  border-radius: 14px !important;
  border-color: var(--glass-border) !important;
}
[data-testid="stChatInput"] { background: transparent; }
[data-testid="stSlider"] [role="slider"] { background: var(--cyan); box-shadow: 0 0 0 4px rgba(0, 229, 255, 0.2); }
[data-testid="stProgress"] > div > div > div { background: rgba(255, 255, 255, 0.08); border-radius: 999px; }
[data-testid="stProgress"] > div > div > div > div { background: var(--cyan); border-radius: 999px; }

/* ---- Sélecteur de langue (radio horizontale en pilule) ------------------ */
[data-testid="stRadio"] [role="radiogroup"] { gap: 0.4rem; flex-wrap: nowrap; }
[data-testid="stRadio"] label {
  border: 1px solid var(--glass-border);
  border-radius: 999px;
  padding: 0.25rem 0.9rem;
  background: var(--glass);
  cursor: pointer;
  transition: background 0.18s ease, border-color 0.18s ease;
}
[data-testid="stRadio"] label > div:first-child { display: none; }  /* cache le rond natif */
[data-testid="stRadio"] label:has(input:checked) { background: rgba(0, 229, 255, 0.16); border-color: var(--cyan); }
[data-testid="stRadio"] label:has(input:checked) p { color: var(--cyan); }

/* ---- Métriques et badges ------------------------------------------------ */
[data-testid="stMetric"] {
  background: var(--glass);
  border: 1px solid var(--glass-border);
  border-radius: 16px;
  padding: 0.8rem 1rem;
}
[data-testid="stMetricValue"] { font-family: var(--font-display); color: var(--cyan); }
.badge {
  display: inline-block;
  font-family: var(--font-display);
  font-weight: 600;
  font-size: 1.05rem;
  padding: 0.45rem 1.1rem;
  border-radius: 999px;
  border: 1px solid;
}
.badge-alert { color: var(--red);   border-color: var(--red);   background: rgba(255, 61, 0, 0.12); }
.badge-ok    { color: var(--green); border-color: var(--green); background: rgba(0, 230, 118, 0.12); }
.badge-neutral { color: var(--muted); border-color: rgba(138, 151, 173, 0.5); background: var(--glass); }

/* ---- Brand et en-têtes de page ----------------------------------------- */
.page-sub { color: var(--muted); max-width: 70ch; margin-top: -0.4rem; }

/* ---- Accessibilité ------------------------------------------------------ */
:focus-visible { outline: 2px solid var(--cyan); outline-offset: 3px; }
::-webkit-scrollbar { width: 10px; }
::-webkit-scrollbar-thumb { background: rgba(0, 229, 255, 0.25); border-radius: 8px; }

/* ---- Landing page ------------------------------------------------------- */
.hero-title {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: clamp(2.2rem, 5.4vw, 4.2rem);
  line-height: 1.05;
  letter-spacing: -0.03em;
  max-width: 16ch;
  margin: 3vh 0 1rem 0;
  color: var(--text);
}
.hero-sub {
  font-size: clamp(1rem, 1.6vw, 1.2rem);
  color: #B7C2D6;
  max-width: 62ch;
  margin-bottom: 1.6rem;
}
.st-key-cta_enter button {
  font-family: var(--font-display);
  font-size: 1.05rem;
  padding: 0.8rem 1.8rem;
  border-radius: 16px;
  box-shadow: 0 0 36px rgba(0, 229, 255, 0.22);
}
.soil-visual { margin: 2.2rem 0 0.4rem 0; }
.soil-visual svg { width: 100%; height: auto; display: block; }
.soil-cell { fill: var(--f); animation: soil-dry 1.8s ease-out both; animation-delay: var(--d); }
@keyframes soil-dry { from { fill: #00E5FF; } }   /* part de l'humide, finit sur la valeur réelle */
.soil-legend { display: flex; justify-content: space-between; color: var(--muted); font-size: 0.9rem; margin-bottom: 2rem; }
.landing-footer { color: var(--muted); font-size: 0.85rem; margin-top: 2.5rem; }

@media (prefers-reduced-motion: reduce) {
  .soil-cell { animation: none; }
  * { transition: none !important; }
}
</style>
"""

# Sur la landing : plein écran, sans sidebar ni bouton de repli.
_LANDING_CSS = """
<style>
[data-testid="stSidebar"], [data-testid="stSidebarCollapsedControl"], [data-testid="stToolbar"] { display: none; }
[data-testid="stMainBlockContainer"] { min-height: 100vh; padding-top: 1.5rem; padding-bottom: 2rem; }
</style>
"""


def inject_css(landing: bool = False) -> None:
    """Injecte le thème global. `landing=True` ajoute la mise en page plein écran."""
    st.markdown(_BASE_CSS, unsafe_allow_html=True)
    if landing:
        st.markdown(_LANDING_CSS, unsafe_allow_html=True)


# --------------------------------------------------------------------------
# Briques réutilisables
# --------------------------------------------------------------------------
def glass_container(key: str):
    """
    Conteneur "verre dépoli". Le préfixe `glass` dans la clé déclenche le style CSS
    (classe `st-key-glass...`). Usage : `with glass_container("stats"): ...`
    """
    return st.container(key=f"glass_{key}")


def feature_card(key: str, icon: str, title: str, body: str) -> None:
    """Carte glassmorphism avec icône Material, titre et texte."""
    with glass_container(key):
        st.markdown(f"#### :material/{icon}: {title}")
        st.markdown(body)


def page_header(title: str, subtitle: str, icon: str) -> None:
    """En-tête standard d'une page du workspace."""
    st.markdown(f"## :material/{icon}: {title}")
    st.markdown(f'<p class="page-sub">{html.escape(subtitle)}</p>', unsafe_allow_html=True)


def trend_badge(significant: bool, direction: str) -> None:
    """
    Affiche le verdict du test de Mann-Kendall.

    significant : True si p < 0.05
    direction   : "decreasing" | "increasing" | "no_trend"
    Rouge = assèchement significatif, vert = humidification significative,
    gris = tendance non significative.
    """
    if not significant:
        css, label = "badge-neutral", t("mk.not_significant")
    elif direction == "decreasing":
        css, label = "badge-alert", t("mk.significant")
    else:
        css, label = "badge-ok", t("mk.significant")
    st.markdown(f'<span class="badge {css}">{html.escape(label)}</span>', unsafe_allow_html=True)
    st.caption(t(f"mk.direction.{direction}"))


def apply_plotly_theme(fig):
    """Applique le thème sombre transparent aux figures Plotly (px ou go)."""
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Instrument Sans, Segoe UI, sans-serif", color=COLORS["text"]),
        title_font=dict(family="Sora, Segoe UI, sans-serif", size=18),
        margin=dict(l=10, r=10, t=50, b=10),
        coloraxis_colorbar=dict(outlinewidth=0, tickfont=dict(color=COLORS["muted"])),
    )
    fig.update_xaxes(gridcolor="rgba(255,255,255,0.06)", zerolinecolor="rgba(255,255,255,0.1)")
    fig.update_yaxes(gridcolor="rgba(255,255,255,0.06)", zerolinecolor="rgba(255,255,255,0.1)")
    return fig


# --------------------------------------------------------------------------
# Sélecteur de langue
# --------------------------------------------------------------------------
def language_selector(location: str) -> None:
    """
    Bascule FR / EN. `location` ("landing" ou "sidebar") sert à construire une clé de
    widget unique. La valeur du widget est resynchronisée sur la langue globale à chaque
    exécution, donc les deux sélecteurs ne divergent jamais. Le changement est appliqué
    par callback : toute l'application se redessine dans la nouvelle langue au même clic.
    """
    widget_key = f"lang_selector_{location}"
    st.session_state[widget_key] = get_language()
    st.radio(
        t("lang.label"),
        options=list(LANGUAGES),
        format_func=lambda code: LANGUAGE_LABELS[code],
        horizontal=True,
        key=widget_key,
        on_change=_on_language_change,
        args=(widget_key,),
        label_visibility="collapsed",
    )


# --------------------------------------------------------------------------
# Visuel de la landing : grille d'humidité qui s'assèche de gauche à droite
# --------------------------------------------------------------------------
def _lerp(a: float, b: float, x: float) -> float:
    return a + (b - a) * x


def _moisture_grid_svg(cols: int = 40, rows: int = 11, cell: int = 18, gap: int = 4) -> str:
    """
    Génère une grille SVG déterministe (pas d'aléatoire, rendu identique à chaque run).
    L'humidité décroît de gauche à droite avec un bruit sinusoïdal pour un aspect organique.
    Chaque cellule porte sa couleur finale (--f) et un délai (--d) : l'animation CSS fait
    "sécher" la grille en une vague unique au chargement.
    """
    wet, dry = (0, 229, 255), (255, 61, 0)
    width = cols * (cell + gap) - gap
    height = rows * (cell + gap) - gap
    cells = []
    for c in range(cols):
        for r in range(rows):
            noise = (math.sin(c * 1.7 + r * 0.9) + math.sin(c * 0.6 - r * 1.9) + 2) / 4  # 0..1
            moisture = min(1.0, max(0.0, 1 - 0.9 * c / (cols - 1) + (noise - 0.5) * 0.55))
            rgb = tuple(int(_lerp(dry[i], wet[i], moisture)) for i in range(3))
            opacity = 0.35 + 0.6 * abs(moisture - 0.5) * 2 if 0.35 < moisture < 0.65 else 0.95
            cells.append(
                f'<rect class="soil-cell" x="{c * (cell + gap)}" y="{r * (cell + gap)}" '
                f'width="{cell}" height="{cell}" rx="4" opacity="{opacity:.2f}" '
                f'style="--f:rgb({rgb[0]},{rgb[1]},{rgb[2]});--d:{c * 45}ms"/>'
            )
    return (
        f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="{html.escape(t("landing.visual_alt"))}" '
        f'xmlns="http://www.w3.org/2000/svg">{"".join(cells)}</svg>'
    )


# --------------------------------------------------------------------------
# Landing page
# --------------------------------------------------------------------------
def render_landing() -> None:
    """
    Page d'accueil plein écran : titre, explication du stress hydrique, bouton d'entrée
    et sélecteur de langue. Le clic sur le bouton bascule la vue vers "workspace".
    """
    inject_css(landing=True)

    brand_col, lang_col = st.columns([3, 1.4], vertical_alignment="center")
    with brand_col:
        st.markdown(f"#### :material/satellite_alt: {t('app.name')}")
    with lang_col:
        language_selector("landing")

    st.markdown(f'<h1 class="hero-title">{html.escape(t("landing.title"))}</h1>', unsafe_allow_html=True)
    st.markdown(f'<p class="hero-sub">{html.escape(t("landing.subtitle"))}</p>', unsafe_allow_html=True)

    st.button(
        t("landing.cta"),
        key="cta_enter",
        icon=":material/rocket_launch:",
        type="primary",
        on_click=_enter_workspace,
    )

    # Visuel : un seul moment animé, au chargement.
    st.markdown(
        f'<div class="soil-visual">{_moisture_grid_svg()}</div>'
        f'<div class="soil-legend"><span>{html.escape(t("landing.legend_wet"))}</span>'
        f'<span>{html.escape(t("landing.legend_dry"))}</span></div>',
        unsafe_allow_html=True,
    )

    cards = (
        ("landing_1", "satellite_alt", "landing.card1"),
        ("landing_2", "query_stats", "landing.card2"),
        ("landing_3", "psychology", "landing.card3"),
    )
    for col, (key, icon, prefix) in zip(st.columns(3), cards):
        with col:
            feature_card(key, icon, t(f"{prefix}.title"), t(f"{prefix}.body"))

    st.markdown(f'<p class="landing-footer">{html.escape(t("app.footer"))}</p>', unsafe_allow_html=True)


# --------------------------------------------------------------------------
# Sidebar du workspace
# --------------------------------------------------------------------------
def render_sidebar() -> str:
    """
    Sidebar : marque, navigation en 3 étapes, bascule de langue, retour à l'accueil.
    Retourne la clé de la page active ("acquisition", "dashboard" ou "assistant").
    """
    with st.sidebar:
        st.markdown(f"#### :material/satellite_alt: {t('app.name')}")
        st.caption(t("nav.title"))

        current = st.session_state.get("page", PAGES[0])
        for page in PAGES:
            st.button(
                t(f"nav.{page}"),
                key=f"nav_{page}",
                icon=f":material/{PAGE_ICONS[page]}:",
                type="primary" if page == current else "secondary",
                width="stretch",
                on_click=_go_page,
                args=(page,),
            )

        st.divider()
        st.caption(t("lang.label"))
        language_selector("sidebar")

        st.divider()
        st.button(
            t("nav.home"),
            key="nav_home",
            icon=":material/arrow_back:",
            width="stretch",
            on_click=_go_home,
        )

    return st.session_state.get("page", PAGES[0])
