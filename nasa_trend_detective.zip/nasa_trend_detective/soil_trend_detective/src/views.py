"""
src/views.py
============
Pages du workspace.
"""

from __future__ import annotations

import streamlit as st

from src import analytics, data_manager as dm
from src.i18n import t, get_language
from src.ui_components import (MOISTURE_COLORSCALE, apply_plotly_theme, glass_container,
                               page_header, trend_badge)


def _selected_region() -> str:
    return st.session_state.setdefault("region", "sahel")


def _region_selector() -> str:
    if "custom_ds" in st.session_state:
        return "custom"
        
    st.selectbox(
        t("region.label"), options=list(analytics.REGIONS), key="region",
        format_func=lambda r: t(f"region.{r}"),
    )
    return st.session_state["region"]


# --------------------------------------------------------------------------
# 1. Acquisition
# --------------------------------------------------------------------------
_STATUS_KEYS = {"start": "acq.status.downloading", "chunk": "acq.status.chunk",
                "resumed": "acq.status.resumed", "interrupted": "acq.status.interrupted",
                "done": "acq.status.done", "cached": "acq.status.cached"}


def render_acquisition() -> None:
    page_header(t("acq.title"), t("acq.subtitle"), "cloud_download")

    mode = dm.resolve_mode("auto")
    status = dm.get_status(mode)

    with glass_container("acq_dataset"):
        st.markdown(f"#### :material/database: {t('acq.dataset.title')}")
        st.markdown(f"**{t('acq.dataset.name')}**  \n{t('acq.dataset.variables')}")
        st.caption(t(f"acq.mode.{mode}"))
        
        if mode == "demo":
            st.caption(t("acq.credentials_hint"))
            simulate = st.checkbox(t("acq.simulate_interrupt"), key="simulate_interrupt")
        else:
            simulate = False

        partial = 0 < status["done"] < status["total"]
        label = t("acq.button_resume") if partial else t("acq.button")
        clicked = st.button(label, icon=":material/download:", type="primary", key="btn_download")

        bar = st.progress(status["done"] / status["total"], text=t("acq.progress.label"))
        message = st.empty()
        
        if not clicked:
            message.caption(t("acq.status.idle") if status["done"] == 0 else
                            t("acq.status.chunk", done=status["done"], total=status["total"]))

        if clicked:
            for ev in dm.iter_acquisition(mode, interrupt_after=6 if simulate else None):
                bar.progress(ev.fraction, text=t("acq.progress.label"))
                if ev.kind == "error":
                    message.error(t("acq.error", detail=ev.detail))
                elif ev.kind in _STATUS_KEYS:
                    message.caption(t(_STATUS_KEYS[ev.kind], done=ev.done, total=ev.total, files=ev.detail))

    # Upload
    st.divider()
    with glass_container("acq_upload"):
        st.markdown(f"#### :material/upload_file: {t('acq.upload.title')}")
        st.caption(t("acq.upload.hint"))
        
        uploaded_files = st.file_uploader(
            "Glissez vos fichiers ici", 
            type=["csv", "nc"], 
            accept_multiple_files=True, 
            label_visibility="collapsed"
        )
        
        if uploaded_files:
            st.markdown("### Associez chaque fichier à une variable")
            assignments = {}
            var_options = ["Ignorer", "soil_moisture", "precipitation", "temperature", "evapotranspiration", "runoff", "aerosol"]
            
            for i, f in enumerate(uploaded_files):
                col1, col2 = st.columns([2, 1])
                with col1:
                    st.info(f":material/description: {f.name}")
                with col2:
                    default_idx = 0
                    fname = f.name.lower()
                    if "soil" in fname or "moi" in fname: default_idx = 1
                    elif "precip" in fname or "rain" in fname: default_idx = 2
                    elif "temp" in fname or "t2m" in fname: default_idx = 3
                    elif "evap" in fname: default_idx = 4
                    elif "runoff" in fname or "qs" in fname: default_idx = 5
                    elif "aerosol" in fname: default_idx = 6
                    
                    assignments[f.name] = st.selectbox(
                        f"Variable pour {f.name}", options=var_options, index=default_idx,
                        key=f"assign_{i}", label_visibility="collapsed"
                    )
            
            if st.button("Confirmer l'import", icon=":material/check:", type="primary"):
                try:
                    custom_ds, selected_files = dm.parse_assigned_files(uploaded_files, assignments)
                    st.session_state["custom_ds"] = custom_ds
                    st.success("Fichiers fusionnés avec succès !")
                except Exception as e:
                    st.error(f"Erreur : {e}")
                
        if "custom_ds" in st.session_state:
            if st.button("Effacer les données importées", icon=":material/delete:"):
                del st.session_state["custom_ds"]
                st.rerun()

    if "custom_ds" in st.session_state:
        st.info("Données personnalisées chargées. Allez dans le Tableau de bord.")
    else:
        ready_mode = dm.get_ready_mode()
        if ready_mode:
            st.success("Données NASA prêtes.")


# --------------------------------------------------------------------------
# 2. Tableau de bord
# --------------------------------------------------------------------------
def render_dashboard() -> None:
    page_header(t("dash.title"), t("dash.subtitle"), "monitoring")

    if "custom_ds" in st.session_state:
        ds = st.session_state["custom_ds"]
        sig = "custom_upload"
    else:
        try:
            ds = dm.load_dataset()
            sig = dm.dataset_signature(dm.get_ready_mode())
        except FileNotFoundError:
            st.info(t("dash.no_data"))
            return
            
    region = _region_selector()

    with glass_container("dash_map"):
        st.markdown(f"#### :material/map: {t('dash.map.title')}")
        fig = analytics.build_animated_map(ds, sig, region, MOISTURE_COLORSCALE, t("dash.map.title"), t("dash.map.colorbar"), t("dash.map.time"))
        st.plotly_chart(apply_plotly_theme(fig), width="stretch")

    with glass_container("dash_stats"):
        st.markdown(f"#### :material/query_stats: {t('dash.stats.title')}")
        trend = analytics.trend_for_region(ds, sig, region)
        left, right = st.columns([1, 2])
        with left:
            trend_badge(trend.significant, trend.direction)
            st.metric(t("mk.p_value"), f"{trend.p_value:.4f}")
            st.metric(t("mk.slope"), t("mk.slope_unit", value=f"{trend.slope_per_year:+.3f}"))
        with right:
            line = analytics.annual_trend_line(ds, sig, region)
            fig = analytics.trend_figure(line, {"title": t("dash.series.title"), "actual": t("dash.series.actual"), "fit": t("dash.series.fit"), "axis": t("dash.series.axis")})
            st.plotly_chart(apply_plotly_theme(fig), width="stretch")

    with glass_container("dash_whatif"):
        st.markdown(f"#### :material/thermostat: {t('whatif.title')}")
        delta = st.slider(t("whatif.slider_short"), 0.5, 4.0, 1.5, 0.5, key="whatif_delta")
        res = analytics.project_whatif(ds, sig, region, delta)

        col_a, col_b = st.columns(2)
        with col_a:
            fig = analytics.whatif_figure(res, "projected", MOISTURE_COLORSCALE, t("whatif.map.title", delta=delta), t("dash.map.colorbar"))
            st.plotly_chart(apply_plotly_theme(fig), width="stretch")
        with col_b:
            fig = analytics.whatif_figure(res, "change", MOISTURE_COLORSCALE, t("whatif.map.change"), t("dash.map.colorbar"))
            st.plotly_chart(apply_plotly_theme(fig), width="stretch")
        st.markdown(t("whatif.result", delta=delta, before=f"{res['mean_before']:.1f}", after=f"{res['mean_after']:.1f}"))


# --------------------------------------------------------------------------
# 3. Assistant IA
# --------------------------------------------------------------------------
def _render_message(msg: dict) -> None:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("shap"):
            from src.explainability import plot_waterfall
            with st.expander("🔍 Voir le détail du calcul (SHAP)", expanded=False):
                st.plotly_chart(apply_plotly_theme(plot_waterfall(msg["shap"])), width="stretch", key=f"shap_{msg['id']}")
        if msg.get("sources"):
            st.caption(f"{t('chat.sources')} : " + ", ".join(msg["sources"]))


def render_assistant() -> None:
    page_header(t("chat.title"), t("chat.subtitle"), "forum")

    if "custom_ds" in st.session_state:
        ds = st.session_state["custom_ds"]
        sig = "custom_upload"
    else:
        try:
            ds = dm.load_dataset()
            sig = dm.dataset_signature(dm.get_ready_mode())
        except FileNotFoundError:
            st.info(t("dash.no_data"))
            return
            
    region = _region_selector()

    history = st.session_state.setdefault("messages", [])
    
    if history and st.button(t("chat.clear"), icon=":material/delete:", key="btn_clear"):
        st.session_state["messages"] = history = []

    pending = None
    if not history:
        st.caption(t("chat.empty"))
        for i, key in enumerate(("chat.example1", "chat.example2")):
            if st.button(t(key), key=f"example_{i}", icon=":material/chat:"):
                pending = t(key)

    for msg in history:
        _render_message(msg)

    question = st.chat_input(t("chat.placeholder")) or pending
    if not question:
        return

    history.append({"id": len(history), "role": "user", "content": question})
    _render_message(history[-1])

    with st.chat_message("assistant"):
        with st.spinner(t("chat.thinking")):
            reply = _build_reply(ds, sig, region, question, len(history))
        history.append(reply)
    st.rerun()


def _build_reply(ds, sig: str, region: str, question: str, msg_id: int) -> dict:
    from src import explainability, chatbot
    import re

    trend = analytics.trend_for_region(ds, sig, region)
    shap_result = explainability.explain_region(ds, sig, region)

    # =======================================================================
    # 1. SÉCURITÉ : SOLS / SÉCHERESSE (Instantané, jamais d'appel API)
    # =======================================================================
    # On cherche : sec, seche, sécheresse, sol, sols, dry, drought, soil
    if re.search(r"(sec|s[eè]che|s[eé]cheresse|sol|sols|dry|drought|soil)", question, re.IGNORECASE) and shap_result:
        reply_text = explainability.explanation_text(shap_result)
        return {
            "id": msg_id, "role": "assistant", 
            "content": reply_text, "sources": ["Analyse locale de l'application"], 
            "shap": shap_result
        }

    # =======================================================================
    # 2. SÉCURITÉ : STATISTIQUES / MATHS (Instantané, jamais d'appel API)
    # =======================================================================
    # On cherche : tendance, stat, mann, theil, etc.
    if re.search(r"(tendance|trend|mann|theil|significant|significative|p-value|maths|statist|statistique)", question, re.IGNORECASE):
        if get_language() == "fr":
            reply_text = (
                f"**Explication mathématique**\n"
                f"Une **tendance significative** (p-value = {trend.p_value:.4f}) signifie que le changement observé n'est pas dû au hasard. "
                f"Le test de **Mann-Kendall** confirme que le sol s'assèche de manière structurelle. "
                f"La pente de **Theil-Sen** ({trend.slope_per_year:+.3f} kg/m²/an) indique la vitesse du changement."
            )
        else:
            reply_text = (
                f"**Mathematical explanation**\n"
                f"A **significant trend** (p-value = {trend.p_value:.4f}) means the change is not due to chance. "
                f"The **Mann-Kendall** test confirms the soil is structurally drying. "
                f"The **Theil-Sen** slope ({trend.slope_per_year:+.3f} kg/m²/yr) indicates the rate of change."
            )
        return {"id": msg_id, "role": "assistant", "content": reply_text, "sources": ["Analyse de l'application"]}

    # =======================================================================
    # 3. GEMINI : POUR TOUT LE RESTE
    # =======================================================================
    region_name = t(f"region.{region}") if region != "custom" else "Fichier personnalisé"
    context_lines = [
        f"Zone d'étude : {region_name}.",
        f"Test de Mann-Kendall : {t(f'mk.direction.{trend.direction}')}.",
        f"p-value : {trend.p_value:.4f}.",
        f"Pente de Theil-Sen : {trend.slope_per_year:+.3f} kg/m²/an.",
    ]
    
    if shap_result:
        from src.explainability import explanation_parts
        parts = explanation_parts(shap_result, top=4)
        context_lines.append(f"Facteurs SHAP expliquant la sécheresse : {parts}.")
        context_lines.append(f"Humidité prédite : {shap_result['prediction']:.1f} kg/m².")

    app_context = "\n".join(context_lines)

    try:
        reply_text = chatbot.generate_response(question, app_context)
        sources = ["Analyse de l'application", "Connaissances Gemini"]
    except Exception as exc:
        # Si l'API plante, on affiche un message propre au lieu d'une erreur 404
        reply_text = f"⚠️ L'IA est momentanément indisponible. Veuillez réessayer."
        sources = []

    return {"id": msg_id, "role": "assistant", "content": reply_text, "sources": sources}
