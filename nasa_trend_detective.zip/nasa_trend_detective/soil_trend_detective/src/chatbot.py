"""
src/chatbot.py
==============
Moteur de chatbot LLM.
"""

from __future__ import annotations

import os
import streamlit as st
import google.generativeai as genai

class MissingLLMKey(RuntimeError):
    pass

def _secret(name: str) -> str | None:
    value = os.environ.get(name)
    if value: return value
    try: return st.secrets.get(name)
    except Exception: return None

def _get_api_key() -> str:
    key = _secret("GEMINI_API_KEY") or _secret("GOOGLE_API_KEY")
    if not key:
        raise MissingLLMKey("Clé API introuvable. Vérifiez .streamlit/secrets.toml.")
    return key

def generate_response(question: str, context: str) -> str:
    genai.configure(api_key=_get_api_key())
    
    # Le modèle qui a fonctionné dans ton terminal
    model = genai.GenerativeModel('gemini-3.8-flash')

    system_prompt = f"""
Tu es l'Assistant Scientifique de l'application "Soil Trend Detective" (NASA Space Apps).
Tu t'adresses à des décideurs, des agriculteurs et des éleveurs.

Voici les données actuelles de l'application (utilise-les pour les chiffres) :
--- CONTEXTE ---
{context}
----------------

Tes instructions :
1. Sois chaleureux, professionnel et pédagogue.
2. EXPLICATION : Si on te demande d'expliquer un résultat (Mann-Kendall, SHAP, tendance), utilise le contexte mathématique fourni.
3. SECTEURS : Si on te demande les conséquences, parle d'agriculture (rendements, irrigation), d'élevage (manque d'eau pour le bétail) et de nappes phréatiques.
4. Mémoire : Tu peux utiliser tes connaissances générales en climatologie pour enrichir tes réponses.
5. Ne réponds pas par "Je ne sais pas", cherche toujours à déduire une explication logique.

Question de l'utilisateur : {question}
"""

    try:
        response = model.generate_content(system_prompt)
        return response.text
    except Exception as exc:
        if "429" in str(exc) or "quota" in str(exc).lower():
            return "⚠️ **Quota API atteint.** Veuillez réessayer dans quelques minutes."
        return f"⚠️ Erreur de connexion à l'IA : {str(exc)[:150]}..."
