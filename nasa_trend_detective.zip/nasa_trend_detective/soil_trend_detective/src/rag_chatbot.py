"""
src/chatbot.py
==============
Moteur de chatbot pur LLM. Aucune réponse pré-écrite.
Gemini utilise sa mémoire d'entraînement + le contexte fourni.
"""

import os
import streamlit as st
import google.generativeai as genai

class MissingLLMKey(RuntimeError):
    pass

def _secret(name: str) -> str | None:
    value = os.environ.get(name)
    if value: return value
    try: return st.secrets.get(name)
    except Exception: return None

def _get_api_key() -> str:
    key = _secret("GEMINI_API_KEY") or _secret("GOOGLE_API_KEY")
    if not key:
        raise MissingLLMKey("Clé API introuvable. Vérifiez .streamlit/secrets.toml.")
    return key

def generate_response(question: str, context: str) -> str:
    """
    Appelle Gemini. Le prompt système définit son rôle et ses capacités, 
    sans jamais lui dicter une réponse toute faite.
    """
    genai.configure(api_key=_get_api_key())
    
    # Le modèle (gemini-1.5-flash est le plus stable)
    model = genai.GenerativeModel(
        model_name='gemini-1.5-flash',
        generation_config={"temperature": 0.4, "max_output_tokens": 1000}
    )

    # Le prompt qui libère l'IA
    system_prompt = f"""
Tu es l'Assistant Scientifique de l'application "Soil Trend Detective", développée pour le NASA Space Apps Challenge (Défi 2).
Ton rôle est d'aider les utilisateurs (scientifiques, décideurs, agriculteurs) à comprendre le stress hydrique des sols.

Voici les données actuelles de l'application sur lesquelles tu dois te baser pour les chiffres :
--- CONTEXTE ---
{context}
----------------

Voici tes instructions strictes :
1. Sois chaleureux, professionnel et pédagogue.
2. EXPLICATION : Si on te demande d'expliquer un résultat (ex: Mann-Kendall, SHAP, tendance), utilise le contexte mathématique fourni.
3. SECTEURS : Si on te demande les conséquences, utilise tes connaissances générales pour parler d'agriculture (rendements, irrigation), d'élevage (manque d'eau pour le bétail) et de richesses sous-terraines (nappes phréatiques).
4. Mémoire : Tu as le droit d'utiliser tes propres connaissances en climatologie pour enrichir tes réponses, tant que tu respectes les chiffres du contexte.
5. Ne réponds pas par un simple "Je ne sais pas", cherche toujours à déduire une explication logique.

Question de l'utilisateur : {question}
"""

    try:
        response = model.generate_content(system_prompt)
        return response.text
    except Exception as exc:
        if "429" in str(exc) or "quota" in str(exc).lower():
            return "⚠️ **Quota API atteint.** Je ne peux pas répondre pour le moment. Veuillez réessayer dans quelques minutes."
        return f"⚠️ Erreur de connexion à l'IA : {str(exc)[:100]}..."
