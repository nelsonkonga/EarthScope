"""
src/data_manager.py
===================
Acquisition et chargement des données GLDAS pour Soil Trend Detective.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
import io
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterator

import numpy as np
import pandas as pd
import requests
import streamlit as st
import xarray as xr

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = PROJECT_ROOT / "data" / "gldas"

START_YEAR, END_YEAR = 2003, 2023
CHUNK_BYTES = 1 << 20
HTTP_TIMEOUT = 30

GLDAS_BASE_URL = "https://hydro1.gesdisc.eosdis.nasa.gov/data/GLDAS/GLDAS_NOAH10_M.2.1"
GLDAS_FILE_PATTERN = "{year}/GLDAS_NOAH10_M.A{year}{month:02d}.021.nc4"

GLDAS_TO_CANONICAL: dict[str, tuple[str, Callable[[xr.DataArray], xr.DataArray], str]] = {
    "SoilMoi0_10cm_inst": ("soil_moisture", lambda x: x, "kg m-2"),
    "Rainf_f_tavg": ("precipitation", lambda x: x * 86400.0, "mm day-1"),
    "Tair_f_inst": ("temperature", lambda x: x - 273.15, "degC"),
    "Evap_tavg": ("evapotranspiration", lambda x: x * 86400.0, "mm day-1"),
    "Qs_acc": ("runoff", lambda x: x * 8.0, "mm day-1"),
}
CANONICAL_VARS = tuple(v[0] for v in GLDAS_TO_CANONICAL.values())

@dataclass
class DownloadEvent:
    kind: str
    done: int = 0
    total: int = 0
    detail: str = ""
    mode: str = "demo"

    @property
    def fraction(self) -> float:
        return self.done / self.total if self.total else 0.0

def _get_credentials() -> tuple[str, str] | None:
    user = os.environ.get("EARTHDATA_USERNAME")
    password = os.environ.get("EARTHDATA_PASSWORD")
    if not (user and password):
        try:
            user = st.secrets.get("EARTHDATA_USERNAME")
            password = st.secrets.get("EARTHDATA_PASSWORD")
        except Exception:
            user = password = None
    return (user, password) if user and password else None

def resolve_mode(mode: str = "auto") -> str:
    if mode in ("real", "demo"):
        return mode
    return "real" if _get_credentials() else "demo"

def mode_dir(mode: str) -> Path:
    return DATA_ROOT / mode

def _manifest_path(mode: str) -> Path:
    return mode_dir(mode) / "manifest.json"

def _read_manifest(mode: str) -> dict:
    path = _manifest_path(mode)
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    return {"completed": []}

def _write_manifest(mode: str, manifest: dict) -> None:
    path = _manifest_path(mode)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    tmp.replace(path)

def _done_chunks(mode: str) -> set[str]:
    base = mode_dir(mode)
    return {name for name in _read_manifest(mode)["completed"] if (base / name).exists()}

def _mark_done(mode: str, name: str) -> None:
    manifest = _read_manifest(mode)
    if name not in manifest["completed"]:
        manifest["completed"].append(name)
    _write_manifest(mode, manifest)

def build_plan(mode: str, years: range | None = None) -> list[str]:
    years = years or range(START_YEAR, END_YEAR + 1)
    if mode == "demo":
        return [f"gldas_demo_{y}.nc" for y in years]
    return [Path(GLDAS_FILE_PATTERN.format(year=y, month=m)).name for y in years for m in range(1, 13)]

def _real_url(filename: str) -> str:
    year = int(filename.split(".A")[1][:4])
    return f"{GLDAS_BASE_URL}/{year}/{filename}"

def get_status(mode: str) -> dict:
    plan = build_plan(mode)
    done = _done_chunks(mode) & set(plan)
    return {"mode": mode, "done": len(done), "total": len(plan), "ready": len(done) == len(plan)}

def get_ready_mode() -> str | None:
    for mode in ("real", "demo"):
        if get_status(mode)["ready"]:
            return mode
    return None

class EarthdataSession(requests.Session):
    AUTH_HOST = "urs.earthdata.nasa.gov"
    def rebuild_auth(self, prepared_request, response):
        headers = prepared_request.headers
        if "Authorization" in headers:
            original = requests.utils.urlparse(response.request.url).hostname
            redirect = requests.utils.urlparse(prepared_request.url).hostname
            if redirect != original and self.AUTH_HOST not in (original, redirect):
                del headers["Authorization"]

def download_with_resume(session, url, dest, on_bytes=None) -> Path:
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    start = part.stat().st_size if part.exists() else 0
    headers = {"Range": f"bytes={start}-"} if start else {}

    with session.get(url, headers=headers, stream=True, timeout=HTTP_TIMEOUT) as resp:
        if resp.status_code == 416:
            part.replace(dest)
            return dest
        resp.raise_for_status()
        if resp.status_code == 200:
            start = 0
        content_range = resp.headers.get("Content-Range")
        total = int(content_range.split("/")[-1]) if content_range else (start + int(resp.headers.get("Content-Length", 0)) if "Content-Length" in resp.headers else None)
        received = start
        with open(part, "ab" if start else "wb") as fh:
            for block in resp.iter_content(CHUNK_BYTES):
                if block:
                    fh.write(block)
                    received += len(block)
                    if on_bytes: on_bytes(received, total)
    if total is not None and part.stat().st_size != total:
        raise IOError(f"Incomplet: {part.stat().st_size}/{total}")
    part.replace(dest)
    return dest

_LATS = np.arange(-34.0, 38.0, 2.0)
_LONS = np.arange(-18.0, 52.0, 2.0)
_SEED = 237

def _synthetic_year(year: int) -> xr.Dataset:
    rng = np.random.default_rng(_SEED + year)
    lat, lon = np.meshgrid(_LATS, _LONS, indexing="ij")
    months = np.arange(12)
    times = pd.date_range(f"{year}-01-01", periods=12, freq="MS")
    yrs = (year - START_YEAR) + (months + 0.5) / 12
    season = np.cos(2 * np.pi * (months - 6.5) / 12)[:, None, None]
    seasonal = season * np.tanh(lat / 8)[None]
    wetness = np.exp(-((lat / 14) ** 2))[None]
    noise = lambda s: rng.normal(0, s, (12, *lat.shape))
    t = yrs[:, None, None]

    temperature = 30 - 0.35 * np.abs(lat)[None] + 3 * seasonal + 0.04 * t + noise(0.5)
    precipitation = np.clip(0.3 + 5.5 * wetness * (1 + 0.7 * seasonal) + noise(0.6), 0, None)
    evapotranspiration = np.clip(0.5 + 0.08 * (temperature - 10) * (0.4 + wetness) + noise(0.1), 0, None)
    runoff = np.clip(0.12 * precipitation * wetness + noise(0.03), 0, None)
    hotspot = (0.06 + 0.28 * np.exp(-(((lat - 12) / 8) ** 2)) + 0.20 * np.exp(-(((lat + 22) / 7) ** 2)))[None]
    soil = np.clip(10 + 3.0 * precipitation - 4.0 * evapotranspiration - hotspot * t + noise(0.6), 3, 45)

    coords = {"time": times, "lat": _LATS, "lon": _LONS}
    dims = ("time", "lat", "lon")
    units = {v: u for _, (v, _, u) in GLDAS_TO_CANONICAL.items()}
    ds = xr.Dataset(
        {
            "soil_moisture": (dims, soil.astype("float32")),
            "precipitation": (dims, precipitation.astype("float32")),
            "temperature": (dims, temperature.astype("float32")),
            "evapotranspiration": (dims, evapotranspiration.astype("float32")),
            "runoff": (dims, runoff.astype("float32")),
        },
        coords=coords,
    )
    for name, unit in units.items():
        ds[name].attrs["units"] = unit
    return ds

def iter_acquisition(mode="auto", interrupt_after=None, pace=0.12, years=None) -> Iterator[DownloadEvent]:
    mode = resolve_mode(mode)
    plan = build_plan(mode, years)
    total = len(plan)
    base = mode_dir(mode)
    base.mkdir(parents=True, exist_ok=True)
    already = _done_chunks(mode) & set(plan)
    if len(already) == total:
        yield DownloadEvent("cached", total, total, mode=mode)
        return
    yield DownloadEvent("start", len(already), total, mode=mode)
    if already:
        yield DownloadEvent("resumed", len(already), total, mode=mode)
    session = None
    if mode == "real":
        creds = _get_credentials()
        session = EarthdataSession()
        session.auth = creds
    done = len(already)
    produced = 0
    for name in plan:
        if name in already: continue
        if interrupt_after is not None and produced >= interrupt_after:
            yield DownloadEvent("interrupted", done, total, mode=mode)
            return
        try:
            if mode == "demo":
                tmp = base / f"{name}.part"
                _synthetic_year(int(name.split("_")[-1][:4])).to_netcdf(tmp)
                tmp.replace(base / name)
                time.sleep(pace)
            else:
                download_with_resume(session, _real_url(name), base / name)
        except (requests.ConnectionError, requests.Timeout, requests.exceptions.ChunkedEncodingError):
            yield DownloadEvent("interrupted", done, total, mode=mode)
            return
        except Exception as exc:
            yield DownloadEvent("error", done, total, detail=str(exc), mode=mode)
            return
        _mark_done(mode, name)
        done += 1
        produced += 1
        yield DownloadEvent("chunk", done, total, mode=mode)
    yield DownloadEvent("done", done, total, detail=str(done), mode=mode)

def _normalize(ds: xr.Dataset) -> xr.Dataset:
    out = {}
    for gldas_name, (canon, convert, unit) in GLDAS_TO_CANONICAL.items():
        if gldas_name in ds:
            da = convert(ds[gldas_name])
            da.attrs["units"] = unit
            out[canon] = da
        elif canon in ds:
            out[canon] = ds[canon]
    return xr.Dataset(out)

def dataset_signature(mode: str) -> str:
    return hashlib.md5(json.dumps(sorted(_done_chunks(mode))).encode()).hexdigest()

@st.cache_data(show_spinner=False)
def _load_dataset_cached(mode: str, signature: str) -> xr.Dataset:
    base = mode_dir(mode)
    parts = []
    for name in sorted(_done_chunks(mode)):
        with xr.open_dataset(base / name) as raw:
            parts.append(_normalize(raw).load())
    if not parts:
        raise FileNotFoundError(f"Aucune donnée complète dans {base}")
    ds = xr.concat(parts, dim="time").sortby("time")
    if "lat" in ds.dims:
        ds = ds.sortby("lat")
    return ds

def load_dataset(mode: str | None = None) -> xr.Dataset:
    mode = mode or get_ready_mode()
    if mode is None:
        raise FileNotFoundError("Aucune donnée complète.")
    return _load_dataset_cached(mode, dataset_signature(mode))

@st.cache_data(show_spinner=False)
def dataset_summary(mode: str, signature: str) -> dict:
    ds = _load_dataset_cached(mode, signature)
    return {
        "start": str(ds.time.min().values)[:10],
        "end": str(ds.time.max().values)[:10],
        "n_months": int(ds.sizes["time"]),
        "grid": (int(ds.sizes["lat"]), int(ds.sizes["lon"])),
        "variables": list(ds.data_vars),
    }

# ==========================================================================
# GESTION DES UPLOADS
# ==========================================================================
def parse_assigned_files(uploaded_files, assignments) -> tuple[xr.Dataset, dict]:
    """
    Prend les fichiers, crée un Dataset fusionné et garde un seul fichier par variable.
    Retourne le Dataset et un dictionnaire des fichiers sélectionnés.
    """
    parsed_data = {}
    selected_files = {}  # Pour tracer quel fichier a été choisi
    
    for uploaded_file in uploaded_files:
        var_name = assignments.get(uploaded_file.name)
        
        if var_name == "Ignorer" or not var_name:
            continue
            
        # SMART SELECTION : Si on a déjà ce fichier, on l'ignore silencieusement
        if var_name in parsed_data:
            continue
            
        filename = uploaded_file.name.lower()
        
        if filename.endswith('.csv'):
            content = uploaded_file.getvalue().decode('utf-8')
            lines = content.splitlines()
            
            header_idx = 0
            for i, line in enumerate(lines):
                if line.lower().startswith("time,"):
                    header_idx = i
                    break
                    
            df = pd.read_csv(io.StringIO(content), skiprows=header_idx)
            if len(df.columns) < 2: 
                continue
            
            df.columns = ["time", "value"]
            df["time"] = pd.to_datetime(df["time"])
            df = df.set_index("time")
            df["value"] = pd.to_numeric(df["value"].replace(-9999, np.nan))
            
            import re
            match = re.search(r'(\d+)W_(\d+)S_(\d+)E_(\d+)N', uploaded_file.name)
            if match:
                w, s, e, n = map(float, match.groups())
                lat_val = (s + n) / 2.0
                lon_val = -w + (e - w) / 2.0
            else:
                lat_val, lon_val = 1.5, 17.0
            
            da = xr.DataArray(
                df["value"].values[:, None, None],
                coords={"time": df.index, "lat": [lat_val], "lon": [lon_val]},
                dims=("time", "lat", "lon"),
                name=var_name
            )
            parsed_data[var_name] = da
            selected_files[var_name] = uploaded_file.name
            
        elif filename.endswith('.nc'):
            ds = xr.open_dataset(uploaded_file)
            if var_name in ds:
                parsed_data[var_name] = ds[var_name]
                selected_files[var_name] = uploaded_file.name
                
    if not parsed_data:
        raise ValueError("Aucune variable n'a été sélectionnée.")
        
    merged = xr.merge(list(parsed_data.values()), join="inner")
    
    for var in ["soil_moisture", "precipitation", "temperature", "evapotranspiration", "runoff", "aerosol"]:
        if var not in merged:
            merged[var] = xr.zeros_like(merged[list(parsed_data.keys())[0]])
            
    return merged, selected_files
