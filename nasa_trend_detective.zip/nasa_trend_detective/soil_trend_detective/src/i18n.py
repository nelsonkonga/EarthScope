"""
src/i18n.py
===========
Internationalisation (FR / EN-US) pour Soil Trend Detective.

Usage
-----
    from src.i18n import t, get_language, set_language

    st.title(t("app.name"))
    st.write(t("acq.status.chunk", done=3, total=10))

Principes
---------
* Une seule source de vérité : le dictionnaire TRANSLATIONS.
* La langue active vit dans st.session_state["lang"] ("fr" ou "en").
* t(key) ne lève jamais d'exception : si la clé manque dans la langue active,
  on retombe sur l'autre langue, puis sur la clé elle-même (visible à l'écran,
  donc facile à repérer pendant le développement).
* Les valeurs peuvent contenir des champs {nom} remplis via t(key, nom=valeur).
* Vérification de cohérence : `python -m src.i18n` liste les clés manquantes.
"""

from __future__ import annotations

import streamlit as st

# --------------------------------------------------------------------------
# Configuration des langues
# --------------------------------------------------------------------------
DEFAULT_LANGUAGE = "fr"
LANGUAGES = ("fr", "en")
LANGUAGE_LABELS = {"fr": "Français", "en": "English (US)"}
SESSION_KEY = "lang"

# --------------------------------------------------------------------------
# Dictionnaire de traduction
# --------------------------------------------------------------------------
TRANSLATIONS: dict[str, dict[str, str]] = {
    # ======================================================================
    # FRANÇAIS
    # ======================================================================
    "fr": {
        # ---- Application ------------------------------------------------
        "app.name": "Soil Trend Detective",
        "app.page_title": "Soil Trend Detective | Stress hydrique des sols",
        "app.footer": "NASA Space Apps Challenge, Défi 2 : Earth System Trend Detective",
        "lang.label": "Langue",

        # ---- Landing page -----------------------------------------------
        "landing.title": "Le sol s’assèche. Les données le démontrent.",
        "landing.subtitle": (
            "Le stress hydrique du sol apparaît lorsque l’eau disponible dans la terre "
            "ne couvre plus les besoins des plantes : les récoltes baissent, les "
            "sécheresses s’installent. Soil Trend Detective croise plusieurs décennies "
            "d’observations et de réanalyses (GLDAS et MERRA-2) pour mesurer cette "
            "tendance, la tester statistiquement et l’expliquer simplement."
        ),
        "landing.cta": "Entrer dans le laboratoire",
        "landing.visual_alt": (
            "Grille de cellules représentant l’humidité du sol : bleu à gauche (sol humide), "
            "rouge à droite (sol sec)."
        ),
        "landing.legend_wet": "Sol humide",
        "landing.legend_dry": "Sol sec",
        "landing.card1.title": "Des données satellitaires",
        "landing.card1.body": (
            "GLDAS et MERRA-2 fournissent l’humidité du sol, les précipitations et la "
            "température sur une grille mondiale."
        ),
        "landing.card2.title": "Une preuve statistique",
        "landing.card2.body": (
            "Le test de Mann-Kendall indique si la tendance est réelle ou due au hasard. "
            "La pente de Theil-Sen en mesure l’ampleur."
        ),
        "landing.card3.title": "Une IA transparente",
        "landing.card3.body": (
            "L’assistant répond uniquement à partir de documents cités, et un graphique SHAP "
            "montre ce qui explique chaque résultat."
        ),

        # ---- Navigation -------------------------------------------------
        "nav.title": "Navigation",
        "nav.acquisition": "1. Acquisition des données",
        "nav.dashboard": "2. Tableau de bord",
        "nav.assistant": "3. Assistant IA",
        "nav.home": "Retour à l’accueil",

        # ---- Acquisition (Data Manager) ---------------------------------
        "acq.title": "Acquisition des données",
        "acq.subtitle": (
            "Téléchargez les jeux de données GLDAS. Si la connexion est coupée, "
            "le téléchargement reprend là où il s’est arrêté."
        ),
        "acq.button": "Télécharger les données GLDAS",
        "acq.button_resume": "Reprendre le téléchargement",
        "acq.dataset.title": "Jeu de données",
        "acq.dataset.name": "GLDAS Noah Land Surface Model, mensuel",
        "acq.dataset.variables": "Humidité du sol, précipitations, température, évapotranspiration",
        "acq.progress.label": "Progression du téléchargement",
        "acq.status.idle": "Aucun téléchargement en cours.",
        "acq.status.downloading": "Téléchargement en cours…",
        "acq.status.chunk": "Bloc {done} sur {total} reçu",
        "acq.status.resumed": "Reprise détectée : {done} blocs déjà présents sur le disque.",
        "acq.status.interrupted": "Connexion interrompue. Relancez pour reprendre au bloc {done}.",
        "acq.status.done": "Données prêtes : {files} fichier(s) disponible(s).",
        "acq.status.cached": "Les données sont déjà complètes, rien à télécharger.",
        "acq.error": "Échec du téléchargement : {detail}",
        "acq.credentials_hint": (
            "Un compte NASA Earthdata est nécessaire pour télécharger les données réelles. "
            "Sans identifiants, l’application utilise un jeu de démonstration."
        ),
        
        # ---- Nouveaux ajouts Acquisition & Tendances --------------------
        "acq.upload.title": "Importer des données locales",
        "acq.upload.hint": "Glissez-déposez vos fichiers CSV (ex: export Giovanni) ou NetCDF ici.",
        "acq.upload.success": "Fichier {file} importé avec succès.",
        "dash.trend_map.title": "Carte des Tendances (Theil-Sen)",
        "dash.trend_map.hint": "Chaque pixel montre la vitesse de changement. Rouge = assèchement.",
        "dash.series.raw": "Série temporelle brute (mensuelle)",

        # ---- Tableau de bord --------------------------------------------
        "dash.title": "Tableau de bord",
        "dash.subtitle": "Observez l’évolution de l’humidité du sol et vérifiez si la tendance est significative.",
        "dash.no_data": "Aucune donnée chargée. Rendez-vous d’abord dans l’onglet Acquisition.",
        "dash.map.title": "Humidité du sol dans le temps",
        "dash.map.hint": "Faites glisser le curseur sous la carte ou lancez l’animation.",
        "dash.map.colorbar": "Humidité (kg/m²)",
        "dash.map.time": "Date",
        "dash.stats.title": "Test de tendance",
        "dash.stats.region": "Zone analysée",
        "mk.significant": "Tendance significative",
        "mk.not_significant": "Tendance non significative",
        "mk.direction.decreasing": "Le sol s’assèche",
        "mk.direction.increasing": "Le sol s’humidifie",
        "mk.direction.no_trend": "Pas de tendance détectable",
        "mk.p_value": "Valeur p",
        "mk.tau": "Tau de Kendall",
        "mk.slope": "Pente de Theil-Sen",
        "mk.slope_unit": "{value} par an",
        "mk.explain.significant": (
            "Il y a moins de 5 % de chances d’observer une telle évolution par pur hasard."
        ),
        "mk.explain.not_significant": (
            "Les variations observées pourraient s’expliquer par le hasard : "
            "on ne peut pas conclure à une tendance."
        ),
        "glossary.title": "Comprendre les termes",
        "glossary.soil_moisture": (
            "Humidité du sol : quantité d’eau contenue dans la couche de terre accessible aux racines."
        ),
        "glossary.mann_kendall": (
            "Test de Mann-Kendall : vérifie si une série de mesures monte ou descend de façon "
            "régulière, sans supposer une forme particulière."
        ),
        "glossary.theil_sen": (
            "Pente de Theil-Sen : vitesse moyenne de changement, peu sensible aux valeurs extrêmes."
        ),

        # ---- Simulateur What-If -----------------------------------------
        "whatif.title": "Simulateur : et si le climat se réchauffait ?",
        "whatif.slider": "Et si la température augmentait de +{delta} °C ?",
        "whatif.slider_short": "Hausse de température (°C)",
        "whatif.run": "Projeter la sécheresse",
        "whatif.map.title": "Humidité du sol projetée (+{delta} °C)",
        "whatif.map.change": "Variation par rapport à aujourd’hui",
        "whatif.result": (
            "Avec +{delta} °C, l’humidité moyenne du sol passerait de {before} à {after} kg/m²."
        ),
        "whatif.disclaimer": (
            "Projection simplifiée par régression linéaire, à visée pédagogique. "
            "Elle ne remplace pas un modèle climatique complet."
        ),

        # ---- Assistant IA (RAG) -----------------------------------------
        "chat.title": "Assistant IA",
        "chat.subtitle": "Posez une question sur le stress hydrique. Les réponses citent leurs sources.",
        "chat.placeholder": "Posez votre question, par exemple : Pourquoi le sol est-il sec ici ?",
        "chat.thinking": "Analyse des documents en cours…",
        "chat.sources": "Sources",
        "chat.empty": "Aucun message pour l’instant. Posez une première question pour commencer.",
        "chat.clear": "Effacer la conversation",
        "chat.no_answer": "Je ne sais pas : les documents fournis ne contiennent pas cette information.",
        "chat.system_prompt": (
            "Tu es un climatologue de la NASA. Réponds UNIQUEMENT en te basant sur les "
            "documents fournis. Cite tes sources. Si tu ne sais pas, dis-le."
        ),
        "chat.missing_key": "Clé d’API du modèle de langage introuvable. Ajoutez-la dans les secrets Streamlit.",
        "chat.index_missing": "La base documentaire est vide. Ajoutez des documents dans le dossier data/docs.",
        "chat.error": "Le service de réponse est indisponible : {detail}",
        "chat.example1": "Pourquoi le sol est-il sec ici ?",
        "chat.example2": "Que signifie une tendance significative ?",

        # ---- Glass Box AI (SHAP) ----------------------------------------
        "glassbox.title": "Pourquoi cette sécheresse ? Le détail du calcul",
        "glassbox.caption": (
            "Chaque barre montre l’influence d’une variable sur l’humidité du sol prédite. "
            "Rouge : elle assèche. Cyan : elle humidifie."
        ),
        "glassbox.baseline": "Valeur moyenne du modèle",
        "glassbox.prediction": "Valeur prédite",
        "glassbox.summary": "Contributions principales : {parts}.",
        "factor.evapotranspiration": "Évapotranspiration",
        "factor.precipitation": "Précipitations",
        "factor.temperature": "Température",
        "factor.runoff": "Ruissellement",
        "factor.humidity": "Humidité de l’air",
        "factor.wind": "Vent",
        "factor.aerosol": "Aérosols",

        # ---- Régions, séries, sources (ajouts) ----------------------------
        "region.label": "Zone d’étude",
        "region.africa": "Afrique entière",
        "region.sahel": "Sahel",
        "region.southern_africa": "Afrique australe",
        "region.cameroon": "Cameroun et golfe de Guinée",
        "acq.simulate_interrupt": "Simuler une coupure de connexion (mode démonstration)",
        "acq.mode.demo": "Mode démonstration : données synthétiques inspirées de GLDAS",
        "acq.mode.real": "Mode réel : NASA GES DISC (GLDAS)",
        "acq.summary": "{months} mois, du {start} au {end}, grille {lat} x {lon}",
        "dash.series.title": "Humidité moyenne annuelle et pente de Theil-Sen",
        "dash.series.actual": "Moyenne annuelle",
        "dash.series.fit": "Pente de Theil-Sen",
        "dash.series.axis": "Humidité du sol (kg/m²)",
        "source.analysis": "Résultats de l’analyse",
        "analysis.doc.trend": (
            "Zone {region} : {direction}. Test de Mann-Kendall saisonnier sur {n} mois, "
            "valeur p = {p}, tau = {tau}, pente de Theil-Sen = {slope} kg/m² par an."
        ),
        "analysis.doc.shap": (
            "Zone {region} : contributions SHAP à l’humidité du sol prédite sur les 12 derniers mois. "
            "{parts}. Valeur moyenne du modèle {base} kg/m², valeur prédite {pred} kg/m²."
        ),

        # ---- Commun -----------------------------------------------------
        "common.loading": "Chargement…",
        "common.error": "Une erreur est survenue.",
        "common.retry": "Réessayer",
        "common.unit.kgm2": "kg/m²",
    },

    # ======================================================================
    # ENGLISH (US)
    # ======================================================================
    "en": {
        # ---- Application ------------------------------------------------
        "app.name": "Soil Trend Detective",
        "app.page_title": "Soil Trend Detective | Soil water stress",
        "app.footer": "NASA Space Apps Challenge, Challenge 2: Earth System Trend Detective",
        "lang.label": "Language",

        # ---- Landing page -----------------------------------------------
        "landing.title": "The soil is drying out. The data proves it.",
        "landing.subtitle": (
            "Soil water stress happens when the water in the ground no longer meets what "
            "plants need: yields fall and droughts take hold. Soil Trend Detective combines "
            "decades of observations and reanalyses (GLDAS and MERRA-2) to measure this "
            "trend, test it statistically, and explain it in plain language."
        ),
        "landing.cta": "Enter Laboratory",
        "landing.visual_alt": (
            "Grid of cells showing soil moisture: blue on the left (wet soil), "
            "red on the right (dry soil)."
        ),
        "landing.legend_wet": "Wet soil",
        "landing.legend_dry": "Dry soil",
        "landing.card1.title": "Satellite-based data",
        "landing.card1.body": (
            "GLDAS and MERRA-2 provide soil moisture, precipitation, and temperature "
            "on a global grid."
        ),
        "landing.card2.title": "Statistical proof",
        "landing.card2.body": (
            "The Mann-Kendall test tells you whether a trend is real or just chance. "
            "The Theil-Sen slope measures how large it is."
        ),
        "landing.card3.title": "Transparent AI",
        "landing.card3.body": (
            "The assistant answers only from cited documents, and a SHAP chart shows "
            "what drives each result."
        ),

        # ---- Navigation -------------------------------------------------
        "nav.title": "Navigation",
        "nav.acquisition": "1. Data acquisition",
        "nav.dashboard": "2. Dashboard",
        "nav.assistant": "3. AI assistant",
        "nav.home": "Back to home",

        # ---- Acquisition (Data Manager) ---------------------------------
        "acq.title": "Data acquisition",
        "acq.subtitle": (
            "Download the GLDAS datasets. If the connection drops, "
            "the download picks up where it stopped."
        ),
        "acq.button": "Download GLDAS data",
        "acq.button_resume": "Resume download",
        "acq.dataset.title": "Dataset",
        "acq.dataset.name": "GLDAS Noah Land Surface Model, monthly",
        "acq.dataset.variables": "Soil moisture, precipitation, temperature, evapotranspiration",
        "acq.progress.label": "Download progress",
        "acq.status.idle": "No download in progress.",
        "acq.status.downloading": "Downloading…",
        "acq.status.chunk": "Chunk {done} of {total} received",
        "acq.status.resumed": "Resume detected: {done} chunks already on disk.",
        "acq.status.interrupted": "Connection interrupted. Run again to resume at chunk {done}.",
        "acq.status.done": "Data ready: {files} file(s) available.",
        "acq.status.cached": "The data is already complete, nothing to download.",
        "acq.error": "Download failed: {detail}",
        "acq.credentials_hint": (
            "A NASA Earthdata account is required to download the real data. "
            "Without credentials, the app uses a demonstration dataset."
        ),
        
        # ---- Nouveaux ajouts Acquisition & Tendances --------------------
        "acq.upload.title": "Import local data",
        "acq.upload.hint": "Drag and drop your CSV (e.g., Giovanni export) or NetCDF files here.",
        "acq.upload.success": "File {file} imported successfully.",
        "dash.trend_map.title": "Spatial Trend Map (Theil-Sen)",
        "dash.trend_map.hint": "Each pixel shows the rate of change. Red = drying.",
        "dash.series.raw": "Raw time series (monthly)",

        # ---- Dashboard --------------------------------------------------
        "dash.title": "Dashboard",
        "dash.subtitle": "Watch soil moisture change over time and check whether the trend is significant.",
        "dash.no_data": "No data loaded. Go to the Acquisition tab first.",
        "dash.map.title": "Soil moisture over time",
        "dash.map.hint": "Drag the slider below the map or press play.",
        "dash.map.colorbar": "Moisture (kg/m²)",
        "dash.map.time": "Date",
        "dash.stats.title": "Trend test",
        "dash.stats.region": "Analyzed area",
        "mk.significant": "Significant trend",
        "mk.not_significant": "Non-significant trend",
        "mk.direction.decreasing": "The soil is drying",
        "mk.direction.increasing": "The soil is getting wetter",
        "mk.direction.no_trend": "No detectable trend",
        "mk.p_value": "p-value",
        "mk.tau": "Kendall’s tau",
        "mk.slope": "Theil-Sen slope",
        "mk.slope_unit": "{value} per year",
        "mk.explain.significant": (
            "There is less than a 5% chance of seeing a change like this by pure luck."
        ),
        "mk.explain.not_significant": (
            "The observed changes could be explained by chance, "
            "so we cannot conclude there is a trend."
        ),
        "glossary.title": "Understand the terms",
        "glossary.soil_moisture": (
            "Soil moisture: the amount of water held in the layer of soil that roots can reach."
        ),
        "glossary.mann_kendall": (
            "Mann-Kendall test: checks whether a series of measurements steadily rises or falls, "
            "without assuming any particular shape."
        ),
        "glossary.theil_sen": (
            "Theil-Sen slope: the typical rate of change, barely affected by extreme values."
        ),

        # ---- What-If simulator ------------------------------------------
        "whatif.title": "Simulator: what if the climate warmed?",
        "whatif.slider": "What if the temperature rose by +{delta}°C?",
        "whatif.slider_short": "Temperature increase (°C)",
        "whatif.run": "Project the drought",
        "whatif.map.title": "Projected soil moisture (+{delta}°C)",
        "whatif.map.change": "Change from today",
        "whatif.result": (
            "At +{delta}°C, average soil moisture would go from {before} to {after} kg/m²."
        ),
        "whatif.disclaimer": (
            "Simplified linear-regression projection for educational purposes. "
            "It does not replace a full climate model."
        ),

        # ---- AI assistant (RAG) -----------------------------------------
        "chat.title": "AI assistant",
        "chat.subtitle": "Ask a question about soil water stress. Answers cite their sources.",
        "chat.placeholder": "Ask your question, for example: Why is the soil dry here?",
        "chat.thinking": "Analyzing documents…",
        "chat.sources": "Sources",
        "chat.empty": "No messages yet. Ask a first question to get started.",
        "chat.clear": "Clear conversation",
        "chat.no_answer": "I don’t know: the provided documents do not contain this information.",
        "chat.system_prompt": (
            "You are a NASA climatologist. Answer ONLY based on the documents provided. "
            "Cite your sources. If you don’t know, say so."
        ),
        "chat.missing_key": "Language model API key not found. Add it to your Streamlit secrets.",
        "chat.index_missing": "The document base is empty. Add documents to the data/docs folder.",
        "chat.error": "The answer service is unavailable: {detail}",
        "chat.example1": "Why is the soil dry here?",
        "chat.example2": "What does a significant trend mean?",

        # ---- Glass Box AI (SHAP) ----------------------------------------
        "glassbox.title": "Why this drought? The calculation, opened up",
        "glassbox.caption": (
            "Each bar shows how much a variable pushes the predicted soil moisture. "
            "Red: it dries the soil. Cyan: it wets it."
        ),
        "glassbox.baseline": "Model average",
        "glassbox.prediction": "Predicted value",
        "glassbox.summary": "Main contributions: {parts}.",
        "factor.evapotranspiration": "Evapotranspiration",
        "factor.precipitation": "Precipitation",
        "factor.temperature": "Temperature",
        "factor.runoff": "Runoff",
        "factor.humidity": "Air humidity",
        "factor.wind": "Wind",
        "factor.aerosol": "Aerosols",

        # ---- Regions, series, sources (additions) -------------------------
        "region.label": "Study area",
        "region.africa": "All of Africa",
        "region.sahel": "Sahel",
        "region.southern_africa": "Southern Africa",
        "region.cameroon": "Cameroon and Gulf of Guinea",
        "acq.simulate_interrupt": "Simulate a connection drop (demo mode)",
        "acq.mode.demo": "Demo mode: synthetic data inspired by GLDAS",
        "acq.mode.real": "Real mode: NASA GES DISC (GLDAS)",
        "acq.summary": "{months} months, from {start} to {end}, {lat} x {lon} grid",
        "dash.series.title": "Annual mean moisture and Theil-Sen slope",
        "dash.series.actual": "Annual mean",
        "dash.series.fit": "Theil-Sen slope",
        "dash.series.axis": "Soil moisture (kg/m²)",
        "source.analysis": "Analysis results",
        "analysis.doc.trend": (
            "Area {region}: {direction}. Seasonal Mann-Kendall test over {n} months, "
            "p-value = {p}, tau = {tau}, Theil-Sen slope = {slope} kg/m² per year."
        ),
        "analysis.doc.shap": (
            "Area {region}: SHAP contributions to predicted soil moisture over the last 12 months. "
            "{parts}. Model average {base} kg/m², predicted value {pred} kg/m²."
        ),

        # ---- Common -----------------------------------------------------
        "common.loading": "Loading…",
        "common.error": "Something went wrong.",
        "common.retry": "Try again",
        "common.unit.kgm2": "kg/m²",
    },
}


# --------------------------------------------------------------------------
# API publique
# --------------------------------------------------------------------------
def get_language() -> str:
    """Retourne le code de la langue active ("fr" ou "en")."""
    lang = st.session_state.get(SESSION_KEY, DEFAULT_LANGUAGE)
    return lang if lang in LANGUAGES else DEFAULT_LANGUAGE


def set_language(lang: str) -> None:
    """Change la langue active. Ignore silencieusement un code inconnu."""
    if lang in LANGUAGES:
        st.session_state[SESSION_KEY] = lang


def t(key: str, **kwargs) -> str:
    """
    Traduit `key` dans la langue active.

    Ordre de repli : langue active, autre langue, puis la clé brute.
    Les champs {nom} sont remplacés par kwargs ; un champ manquant ne
    provoque pas d'erreur, il reste tel quel dans le texte.
    """
    lang = get_language()
    text = TRANSLATIONS.get(lang, {}).get(key)
    if text is None:
        for other in LANGUAGES:
            text = TRANSLATIONS.get(other, {}).get(key)
            if text is not None:
                break
    if text is None:
        return key
    if kwargs:
        try:
            return text.format(**kwargs)
        except (KeyError, IndexError, ValueError):
            return text
    return text


def t_lang(key: str, lang: str, **kwargs) -> str:
    """Traduit `key` dans une langue précise, sans toucher à l'état de session."""
    text = TRANSLATIONS.get(lang, {}).get(key, key)
    try:
        return text.format(**kwargs) if kwargs else text
    except (KeyError, IndexError, ValueError):
        return text


def missing_keys() -> dict[str, list[str]]:
    """Liste, pour chaque langue, les clés présentes ailleurs mais absentes ici."""
    all_keys = set().union(*(set(d) for d in TRANSLATIONS.values()))
    return {lang: sorted(all_keys - set(d)) for lang, d in TRANSLATIONS.items()}


if __name__ == "__main__":  # python -m src.i18n
    report = missing_keys()
    if any(report.values()):
        for lang, keys in report.items():
            if keys:
                print(f"[{lang}] clés manquantes : {', '.join(keys)}")
    else:
        count = len(TRANSLATIONS[DEFAULT_LANGUAGE])
        print(f"OK : {count} clés, FR et EN synchronisés.")
