import os
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# 1. Lire la clé depuis le fichier secrets
try:
    with open(".streamlit/secrets.toml", "r") as f:
        for line in f:
            if "GEMINI_API_KEY" in line:
                api_key = line.split("=")[1].strip().strip('"').strip("'")
                break
except FileNotFoundError:
    print("❌ Fichier secrets.toml introuvable.")
    exit()

if not api_key:
    print("❌ Clé API introuvable dans le fichier.")
    exit()

print(f"🔑 Clé trouvée : {api_key[:5]}...")

# 2. Définir le prompt EXACT de ton application
_ANSWER_PROMPT = ChatPromptTemplate.from_messages([
    ("system",
     "Tu es l'Assistant Scientifique Expert de l'application 'Soil Trend Detective' (NASA Space Apps). "
     "Tu t'adresses à des décideurs et des agriculteurs. Tu dois être chaleureux, clair et pédagogique.\n\n"
     "Voici tes instructions STRICTES :\n"
     "1. EXPLICATION MATHÉMATIQUE : Si on te demande ce que signifie un test (Mann-Kendall, Theil-Sen, p-value), "
     "explique-le simplement en te basant sur le 'CONTEXTE APPLICATIF'.\n"
     "2. CAUSES PHYSIQUES : Si on demande pourquoi le sol est sec, utilise l'analyse SHAP du contexte. "
     "Dis clairement : 'La sécheresse est due à X% de précipitations et Y% d'évapotranspiration'.\n"
     "3. EXTRAPOLATION SECTORIELLE : Si on demande les conséquences, tu DOIS donner des exemples concrets pour :\n"
     "   - L'agriculture (baisse des rendements, irrigation)\n"
     "   - L'élevage (manque d'eau pour le bétail)\n"
     "   - La pisciculture (assèchement des étangs)\n"
     "   - Les nappes phréatiques (épuisement des réserves).\n"
     "4. Ne dis JAMAIS 'Je ne sais pas' si l'information est dans le CONTEXTE APPLICATIF.\n\n"
     "--- CONTEXTE APPLICATIF (Données de l'application) ---\n{app_context}\n\n"
     "--- DOCUMENTS NASA (Complémentaires) ---\n{docs_context}"),
    ("human", "{question}"),
])

# 3. Simuler un contexte
app_context = """
=== RÉSULTATS DE L'ANALYSE ACTUELLE ===
Facteurs de sécheresse (SHAP) : Évapotranspiration 60 %, Précipitations 29 %, Température 9 %.
Humidité prédite : 11.6 kg/m².
"""
question = "Pourquoi le sol est-il sec ici et quelles sont les conséquences pour les agriculteurs ?"

# 4. Appeler Gemini
print("⏳ Appel de Gemini en cours...")
llm = ChatGoogleGenerativeAI(model="gemini-3.8-flash", temperature=0.4, google_api_key=api_key)
chain = _ANSWER_PROMPT | llm | StrOutputParser()

try:
    resultat = chain.invoke({"app_context": app_context, "docs_context": "Aucun.", "question": question})
    print("\n✅ RÉPONSE DE GEMINI :")
    print("-" * 50)
    print(resultat)
    print("-" * 50)
except Exception as e:
    print(f"\n❌ ERREUR : {e}")
