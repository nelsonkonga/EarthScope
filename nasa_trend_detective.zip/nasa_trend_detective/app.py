"""
app.py
======
Point d'entrée de Soil Trend Detective.

Lancement :  streamlit run app.py

Rôle : initialiser l'état de session (langue, vue, page) et router entre la landing page
et le workspace. Le contenu de chaque page vit dans src/views.py.
"""

import streamlit as st

from src.i18n import t
from src.ui_components import init_session_state, inject_css, render_landing, render_sidebar
from src.views import render_acquisition, render_assistant, render_dashboard

init_session_state()  # langue, vue et page par défaut

st.set_page_config(
    page_title=t("app.page_title"),
    page_icon=":material/satellite_alt:",
    layout="wide",
    initial_sidebar_state="expanded",
)

PAGE_RENDERERS = {
    "acquisition": render_acquisition,
    "dashboard": render_dashboard,
    "assistant": render_assistant,
}

if st.session_state["view"] == "landing":
    render_landing()
else:
    inject_css()
    page = render_sidebar()          # retourne la page active
    PAGE_RENDERERS[page]()
