"""
src/explainability.py
=====================
"Glass Box AI" : explique visuellement pourquoi le sol d'une zone est sec.
"""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
import shap
import streamlit as st
import xarray as xr
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split

from src.analytics import select_region
from src.i18n import t, get_language  # <-- IMPORT DE get_language

POSSIBLE_FEATURES = ("evapotranspiration", "precipitation", "temperature", "runoff", "aerosol")
TARGET = "soil_moisture"
MAX_SAMPLES = 20_000
RECENT_MONTHS = 12

@st.cache_data(show_spinner=False)
def explain_region(_ds: xr.Dataset, signature: str, region: str) -> dict | None:
    sub = select_region(_ds, region)
    available_features = [f for f in POSSIBLE_FEATURES if f in sub.data_vars]
    
    if not available_features or TARGET not in sub.data_vars:
        return None

    x = np.column_stack([sub[f].to_numpy().ravel() for f in available_features])
    y = sub[TARGET].to_numpy().ravel()
    
    ok = np.isfinite(x).all(axis=1) & np.isfinite(y)
    x, y = x[ok], y[ok]

    if len(y) < 50:
        return None

    rng = np.random.default_rng(0)
    if len(y) > MAX_SAMPLES:
        pick = rng.choice(len(y), MAX_SAMPLES, replace=False)
        x, y = x[pick], y[pick]

    x_tr, x_te, y_tr, y_te = train_test_split(x, y, test_size=0.2, random_state=0)
    model = RandomForestRegressor(n_estimators=80, max_depth=10, min_samples_leaf=5,
                                  n_jobs=-1, random_state=0).fit(x_tr, y_tr)
    r2 = float(r2_score(y_te, model.predict(x_te)))

    recent = sub.isel(time=slice(-RECENT_MONTHS, None))
    instance = np.array([[float(recent[f].mean()) for f in available_features]])

    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(instance)[0]
    base = float(np.ravel(explainer.expected_value)[0])

    contributions = {f: float(v) for f, v in zip(available_features, shap_values)}
    total = sum(abs(v) for v in contributions.values()) or 1.0
    
    return {
        "base_value": base,
        "prediction": base + float(sum(contributions.values())),
        "contributions": contributions,
        "shares": {f: 100.0 * abs(v) / total for f, v in contributions.items()},
        "feature_values": {f: float(instance[0, i]) for i, f in enumerate(available_features)},
        "r2": r2,
    }

def plot_waterfall(result: dict) -> go.Figure:
    if not result:
        return go.Figure()

    ordered = sorted(result["contributions"].items(), key=lambda kv: abs(kv[1]), reverse=True)
    labels = [t("glassbox.baseline")] + [t(f"factor.{name}") for name, _ in ordered] + [t("glassbox.prediction")]
    values = [result["base_value"]] + [v for _, v in ordered] + [0]
    measures = ["absolute"] + ["relative"] * len(ordered) + ["total"]
    texts = [f"{result['base_value']:.1f}"] + [f"{v:+.2f}" for _, v in ordered] + [f"{result['prediction']:.1f}"]

    fig = go.Figure(go.Waterfall(
        orientation="h", measure=measures, y=labels, x=values, text=texts, textposition="outside",
        connector=dict(line=dict(color="rgba(255,255,255,0.25)")),
        increasing=dict(marker=dict(color="#00E5FF")),
        decreasing=dict(marker=dict(color="#FF3D00")),
        totals=dict(marker=dict(color="#8A97AD")),
    ))
    fig.update_layout(
        title=t("glassbox.title"),
        xaxis_title=t("dash.series.axis"),
        yaxis=dict(autorange="reversed"),
        height=300, showlegend=False,
    )
    return fig

def explanation_parts(result: dict, top: int = 3) -> str:
    if not result:
        return ""
    ranked = sorted(result["shares"].items(), key=lambda kv: kv[1], reverse=True)[:top]
    return ", ".join(f"{t(f'factor.{name}')} {share:.0f} %" for name, share in ranked)

# --- LA FAMEUSE EXPLICATION EXPERTE ---
def explanation_text(result: dict) -> str:
    """Génère une explication experte, chaleureuse et sectorielle."""
    if not result:
        return ""
        
    parts = explanation_parts(result, top=3)
    pred = result['prediction']
    base = result['base_value']
    
    if get_language() == "fr":
        return (
            f"**Explication scientifique et mathématique**\n"
            f"L'analyse SHAP de notre modèle indique que la sécheresse est principalement due à : **{parts}**. "
            f"Le modèle prédit une humidité du sol de **{pred:.1f} kg/m²** (contre une moyenne historique de {base:.1f} kg/m²).\n\n"
            f"**Causes physiques**\n"
            f"Le déficit de précipitations couplé à une forte évapotranspiration (la chaleur fait s'évaporer l'eau) "
            f"crée un cercle vicieux : le sol s'assèche, la végétation meurt, et le sol devient encore plus chaud.\n\n"
            f"**Conséquences sectorielles (Impacts)**\n"
            f"- **Agriculture** : Baisse drastique des rendements, besoin accru en irrigation, risque de perte des cultures.\n"
            f"- **Élevage** : Raréfaction des points d'eau, stress thermique pour le bétail, baisse de la production laitière.\n"
            f"- **Pisciculture** : Assèchement des étangs et augmentation de la température de l'eau (manque d'oxygène).\n"
            f"- **Richesses sous-terraines** : Risque de surexploitation et d'épuisement des nappes phréatiques pour compenser le manque d'eau de surface."
        )
    else:
        return (
            f"**Scientific and mathematical explanation**\n"
            f"Our SHAP analysis indicates that the drought is primarily driven by: **{parts}**. "
            f"The model predicts soil moisture of **{pred:.1f} kg/m²** (compared to a historical average of {base:.1f} kg/m²).\n\n"
            f"**Physical causes**\n"
            f"The lack of precipitation combined with high evapotranspiration creates a vicious cycle: the soil dries out, vegetation dies, and the soil gets even hotter.\n\n"
            f"**Sectoral consequences (Impacts)**\n"
            f"- **Agriculture**: Drastic drop in yields, increased irrigation needs, risk of crop loss.\n"
            f"- **Livestock**: Scarcity of water points, heat stress for cattle, lower milk production.\n"
            f"- **Fish farming**: Drying up of ponds and increased water temperature (lack of oxygen).\n"
            f"- **Underground resources**: Risk of overexploitation and depletion of groundwater to compensate for surface water loss."
        )
